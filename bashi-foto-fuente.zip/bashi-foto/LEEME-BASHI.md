# BASHI · Fotografía — "Ida y vuelta"

Viaje 3D con scroll para `studiobashi.com/foto`, hecho sobre el motor de viaje 3D (v3).
El viaje ocurre dentro de la cámara: 11 escenas, un rollo de 36 fotos.

## Poner tus fotos

1. Copia tus fotos a la carpeta `fotos/` con nombre `01` a `36` (`01.jpg`, `02.png`, ... `36.jpg`).
2. La que falte se reemplaza por un marco numerado, así que puedes ir de a pocas.
3. Opcional: `fotos/fotos.json` con título, nota y descripción por foto:
   `{"07": {"t": "Título", "d": "Nota corta", "alt": "Qué se ve en la foto"}}`
4. Compila: `pip install pillow` y luego `python3 build.py`
5. Lo que se despliega es el contenido de `dist/site/` dentro de la carpeta `foto/` del sitio.

## Dónde va cada foto

| Fotos | Escena | Cómo se muestran |
|---|---|---|
| 01–06 | El rollo | En espiral, llegan como negativo y se revelan |
| 07–12 | La plaza | Colgadas de cuerdas con ganchos |
| 13–18 | Nueva York | Carteles pegados en tablones de obra |
| 19–23 | Miami | Vallas, con reflejo en el piso mojado |
| 24–28 | Atlanta | Pantallas de la cabina |
| 29–31 | La mezcla | Alrededor de la orquídea de cromo |
| 32–35 | El corte | En la pista central: dirijo, edito, fotografío, mezclo |
| 36 | El visor | Llena la pantalla al final (mejor horizontal) |

## Dónde tocar

| Qué | Dónde |
|---|---|
| Escenas, frases, ritmo del scroll | tabla `SC` en `src/head.js` |
| WhatsApp, Instagram | `CONFIG` en `src/head.js` |
| Escenas 1 a 5 (lente, rollo, niebla, plaza, salto) | `src/world-a.js` |
| Escenas 6 a 11 y telón de fondo | `src/world-b.js` |
| Ruta de cámara (`KEYS`), giro (`rollAt`), bucle | `src/world-c.js` |
| Visor, contador, hoja de contactos | `src/tail.js`, `template.html`, `styles.css` |

## Probar con capturas

`cd pruebas && QS="&q=mid" ./run.sh nombre 1100 700 h0,h28,h51,h82 --cols 4`
(`hNN` = NN % del scroll del viaje; necesita `pip install playwright` y Chromium)

## Estado real de las pruebas

- Probado en Chromium sin tarjeta gráfica: las 11 escenas, calidad alta/media/baja, 320 a 1100 px sin desborde,
  tocar una foto, flechas, hoja de contactos, foto ampliada, movimiento reducido y respaldo sin WebGL.
- Sin probar: teléfonos reales, Safari, Firefox, giroscopio y rendimiento en tarjeta gráfica real.
