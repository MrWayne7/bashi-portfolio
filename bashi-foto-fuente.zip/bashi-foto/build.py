#!/usr/bin/env python3
"""BASHI · Fotografía — "Ida y vuelta" (motor de viaje 3D).

Fotos: pon tus archivos en la carpeta fotos/ con nombre 01 a 36 (01.jpg, 02.png, ... 36.jpg).
       La que falte se reemplaza por un marco de relleno numerado, así se ve dónde va cada una.
Textos opcionales por foto: fotos/fotos.json  ->  {"07": {"t": "Título", "d": "Nota corta", "alt": "Descripción"}}

Genera:
  dist/site/               -> index.html + img/ + js/ + fonts/   (esto es lo que se despliega en /foto)
  dist/inline/index.html   -> un solo archivo, todo incrustado (vista previa)
  dist/test/               -> igual que site (pruebas con capturas)
"""
from PIL import Image, ImageDraw, ImageFont, ImageOps
import base64, io, json, os, random, re, shutil

ROOT = os.path.dirname(os.path.abspath(__file__))
FOTOS = os.environ.get("FOTOS", os.path.join(ROOT, "fotos"))
DIST = os.path.join(ROOT, "dist")
SITE_URL = os.environ.get("SITE_URL", "https://studiobashi.com/foto").rstrip("/")

KEYS = [f"{i:02d}" for i in range(1, 37)]
# en qué escena del viaje aparece cada foto
ESCENA = {}
for a, b, nombre in [(1, 6, "El rollo"), (7, 12, "La plaza"), (13, 18, "Nueva York"), (19, 23, "Miami"),
                     (24, 28, "Atlanta"), (29, 31, "La mezcla"), (32, 35, "El corte"), (36, 36, "El visor")]:
    for i in range(a, b + 1):
        ESCENA[f"{i:02d}"] = nombre
# la hoja de contactos se parte en los tres territorios del viaje
ROLLOS = [("La raíz", "COLOMBIA", 1, 12), ("El norte", "ESTADOS UNIDOS", 13, 28), ("La vuelta", "BOGOTÁ, HOY", 29, 36)]
APAISADAS = {"02", "05", "08", "11", "14", "17", "20", "22", "25", "27", "30", "33", "36"}   # solo para el relleno
TINTE = [((58, 36, 14), (14, 9, 4)), ((18, 28, 58), (6, 7, 16)), ((16, 40, 28), (4, 9, 6))]


def fuente(size, bold=True):
    for p in ("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
              "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
              "/Library/Fonts/Arial.ttf"):
        try:
            return ImageFont.truetype(p, size)
        except Exception:
            pass
    return ImageFont.load_default()


def buscar(key):
    for ext in ("jpg", "jpeg", "png", "webp", "JPG", "JPEG", "PNG", "WEBP"):
        p = os.path.join(FOTOS, f"{key}.{ext}")
        if os.path.exists(p):
            return p
    return None


def relleno(key):
    """Marco de relleno: deja claro qué foto falta y en qué escena va."""
    n = int(key)
    terr = 0 if n <= 12 else (1 if n <= 28 else 2)
    W, H = (1500, 1000) if key in APAISADAS else (1200, 1500)
    c0, c1 = TINTE[terr]
    sm = Image.new("RGB", (48, 48))
    px = sm.load()
    for y in range(48):
        for x in range(48):
            k = min(1.0, max(0.0, (y / 48) * 0.8 + (x / 48) * 0.35))
            px[x, y] = tuple(int(c0[i] + (c1[i] - c0[i]) * k) for i in range(3))
    im = sm.resize((W, H), Image.BICUBIC)
    grano = Image.effect_noise((W, H), 22).convert("RGB")
    im = Image.blend(im, grano, 0.05)
    d = ImageDraw.Draw(im, "RGBA")
    d.line([(0, 0), (W, H)], fill=(236, 232, 223, 26), width=3)
    d.line([(W, 0), (0, H)], fill=(236, 232, 223, 26), width=3)
    m, L = 60, 90
    for (cx, cy, sx, sy) in ((m, m, 1, 1), (W - m, m, -1, 1), (m, H - m, 1, -1), (W - m, H - m, -1, -1)):
        d.line([(cx, cy), (cx + L * sx, cy)], fill=(236, 232, 223, 200), width=5)
        d.line([(cx, cy), (cx, cy + L * sy)], fill=(236, 232, 223, 200), width=5)
    d.text((m + 30, H - m - 470), key, font=fuente(430), fill=(236, 232, 223, 235))
    d.text((m + 40, m + 40), "TU FOTO " + key, font=fuente(64), fill=(255, 179, 71, 255))
    d.text((m + 40, m + 124), ESCENA[key].upper(), font=fuente(44, False), fill=(236, 232, 223, 200))
    return im


def cargar(key):
    p = buscar(key)
    if not p:
        return relleno(key), False
    im = ImageOps.exif_transpose(Image.open(p)).convert("RGB")
    return im, True


def fit(im, maxside):
    w, h = im.size
    if max(w, h) > maxside:
        s = maxside / max(w, h)
        im = im.resize((round(w * s), round(h * s)), Image.LANCZOS)
    return im


def webp(im, q):
    buf = io.BytesIO()
    im.save(buf, "WEBP", quality=q, method=6)
    return buf.getvalue()


def datauri(b, mime="image/webp"):
    return f"data:{mime};base64," + base64.b64encode(b).decode()


def og_image(foto):
    W, H = 1200, 630
    og = Image.new("RGB", (W, H), (0, 0, 0))
    ph = foto.copy()
    s = max(560 / ph.width, H / ph.height)
    ph = ph.resize((round(ph.width * s), round(ph.height * s)), Image.LANCZOS)
    x0, y0 = (ph.width - 560) // 2, (ph.height - H) // 2
    og.paste(ph.crop((x0, y0, x0 + 560, y0 + H)), (W - 560, 0))
    d = ImageDraw.Draw(og)
    d.text((64, 150), "BASHI", font=fuente(150), fill=(236, 232, 223))
    d.text((70, 330), "Fotografía", font=fuente(56), fill=(236, 232, 223))
    d.text((70, 410), "Ida y vuelta, un rollo de 36", font=fuente(32, False), fill=(255, 179, 71))
    d.text((70, 540), "studiobashi.com/foto", font=fuente(28, False), fill=(0, 255, 102))
    return og


def main():
    if os.path.exists(DIST):
        shutil.rmtree(DIST)
    for d in ("inline", "site/img", "site/js", "site/fonts", "test/img", "test/js", "test/fonts"):
        os.makedirs(os.path.join(DIST, d))

    meta = {}
    mp = os.path.join(FOTOS, "fotos.json")
    if os.path.exists(mp):
        meta = json.load(open(mp, encoding="utf-8"))

    tex_inline, tex_site, alt, dims, faltan = {}, {}, {}, {}, []
    tot_big = tot_tex = 0
    ultima = None
    for key in KEYS:
        im, real = cargar(key)
        if not real:
            faltan.append(key)
        if key == "36":
            ultima = im
        big = webp(fit(im, 1600), 80)
        t = fit(im, 1400 if key == "36" else 720)       # la 36 llena la pantalla al final: va más grande
        tb = webp(t, 74)
        tot_big += len(big); tot_tex += len(tb)
        a = round(t.width / t.height, 4)
        dims[key] = t.size
        tex_inline[key] = {"u": datauri(tb), "a": a}
        tex_site[key] = {"u": f"img/t-{key}.webp", "a": a}
        for v in ("site", "test"):
            open(os.path.join(DIST, v, "img", f"{key}.webp"), "wb").write(big)
            open(os.path.join(DIST, v, "img", f"t-{key}.webp"), "wb").write(tb)
        m = meta.get(key, {})
        alt[key] = m.get("alt") or (m.get("t") or (f"Fotograma {key}, {ESCENA[key]}" + ("" if real else " (foto pendiente)")))
    print(f"fotos: {36 - len(faltan)} reales, {len(faltan)} de relleno" + (f" -> faltan: {' '.join(faltan)}" if faltan else ""))
    print(f"peso: grandes {tot_big // 1024} KB, texturas {tot_tex // 1024} KB")

    og = og_image(ultima)
    for v in ("site", "test"):
        og.save(os.path.join(DIST, v, "img", "og.jpg"), "JPEG", quality=86, optimize=True, progressive=True)

    def hoja(src_small, src_big):
        out = []
        for titulo, lugar, a, b in ROLLOS:
            out.append(f'<div class="roll-h"><h3>{titulo}</h3><span>{lugar} &nbsp;{a:02d}–{b:02d}</span></div>\n<div class="strip">')
            for i in range(a, b + 1):
                k = f"{i:02d}"
                w, h = dims[k]
                out.append(f'<button class="fr" type="button" data-k="{k}" data-big="{src_big(k)}" aria-label="Ver el fotograma {k} en grande">'
                           f'<img src="{src_small(k)}" alt="{alt[k]}" width="{w}" height="{h}" loading="lazy" decoding="async"></button>')
            out.append("</div>")
        return "\n".join(out)

    parts = [open(os.path.join(ROOT, "src", f), encoding="utf-8").read() for f in ("head.js", "world-a.js", "world-b.js", "world-c.js", "tail.js")]
    js = "".join(parts)
    open(os.path.join(ROOT, "main.js"), "w", encoding="utf-8").write(js)
    tpl = open(os.path.join(ROOT, "template.html"), encoding="utf-8").read()
    css = open(os.path.join(ROOT, "styles.css"), encoding="utf-8").read()

    cdn = "https://cdnjs.cloudflare.com/ajax/libs"
    libs_cdn = {"three": f"{cdn}/three.js/r128/three.min.js", "gsap": f"{cdn}/gsap/3.12.5/gsap.min.js",
                "lenis": "https://cdn.jsdelivr.net/npm/lenis@1.1.13/dist/lenis.min.js"}
    libs_local = {"three": "js/three.min.js", "gsap": "js/gsap.min.js", "lenis": "js/lenis.min.js"}

    FUENTES = [("Pirata One", 400, "pirata.woff2"), ("Barlow Condensed", 400, "barlow-400.woff2"), ("Barlow Condensed", 500, "barlow-500.woff2"),
               ("Barlow Condensed", 600, "barlow-600.woff2"), ("Barlow Condensed", 700, "barlow-700.woff2"), ("VT323", 400, "vt323.woff2")]

    def fuentes(inline):
        css_f = []
        for fam, w, fn in FUENTES:
            raw = open(os.path.join(ROOT, "fonts", fn), "rb").read()
            src = datauri(raw, "font/woff2") if inline else f"fonts/{fn}"
            css_f.append(f'@font-face{{font-family:"{fam}";src:url("{src}") format("woff2");font-weight:{w};font-style:normal;font-display:swap;}}')
        return "<style>" + "".join(css_f) + "</style>"

    og_meta = (f'<link rel="canonical" href="{SITE_URL}/">\n'
               f'<meta property="og:url" content="{SITE_URL}/">\n'
               f'<meta property="og:image" content="{SITE_URL}/img/og.jpg">\n'
               '<meta property="og:image:width" content="1200">\n<meta property="og:image:height" content="630">\n'
               '<meta name="twitter:card" content="summary_large_image">\n'
               f'<meta name="twitter:image" content="{SITE_URL}/img/og.jpg">')

    def render(tex, libs, fonts, og_tags, sheet, preload_fonts):
        out = tpl.replace("/*__CSS__*/", css)
        j = js.replace("__TEXMAP__", json.dumps(tex)).replace("__META__", json.dumps(meta, ensure_ascii=False)).replace("__LIBS__", json.dumps(libs))
        pre = "\n".join(f'<link rel="preload" as="script" href="{libs[k]}">' for k in ("three", "gsap"))
        if preload_fonts:
            pre += '\n<link rel="preload" as="font" type="font/woff2" href="fonts/pirata.woff2" crossorigin>'
        out = out.replace("<!--__PRELOAD__-->", pre)
        out = out.replace("/*__MAIN_JS__*/", j)
        out = out.replace("<!--__FONTS__-->", fonts).replace("<!--__OG__-->", og_tags).replace("<!--__SHEET__-->", sheet)
        left = sorted(set(re.findall(r"__[A-Z]{3,}__", out)))
        if left:
            print("!! tokens sin reemplazar:", left)
        return out

    open(os.path.join(DIST, "inline", "index.html"), "w", encoding="utf-8").write(
        render(tex_inline, libs_cdn, fuentes(True), "", hoja(lambda k: tex_inline[k]["u"], lambda k: tex_inline[k]["u"]), False))
    site_html = render(tex_site, libs_local, fuentes(False), og_meta, hoja(lambda k: f"img/t-{k}.webp", lambda k: f"img/{k}.webp"), True)
    for v in ("site", "test"):
        open(os.path.join(DIST, v, "index.html"), "w", encoding="utf-8").write(site_html)
        for f in ("three.min.js", "gsap.min.js", "lenis.min.js"):
            shutil.copy(os.path.join(ROOT, "vendor", f), os.path.join(DIST, v, "js", f))
        for _, _, fn in FUENTES:
            shutil.copy(os.path.join(ROOT, "fonts", fn), os.path.join(DIST, v, "fonts", fn))

    for v in ("inline", "site"):
        p = os.path.join(DIST, v, "index.html")
        print(v, "index.html", os.path.getsize(p) // 1024, "KB")
    tot = 0
    for dp, _, fs in os.walk(os.path.join(DIST, "site")):
        for f in fs:
            tot += os.path.getsize(os.path.join(dp, f))
    print("site total", tot // 1024, "KB")


if __name__ == "__main__":
    main()
