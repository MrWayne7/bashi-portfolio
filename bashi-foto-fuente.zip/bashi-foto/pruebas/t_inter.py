import asyncio, os
from playwright.async_api import async_playwright
URL="http://localhost:8765/index.html?snap&q=mid"
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
        pg=await (await b.new_context(viewport={'width':1100,'height':700})).new_page()
        errs=[]
        pg.on('console', lambda m: errs.append(m.text) if m.type in ('error','warning') else None)
        pg.on('pageerror', lambda e: errs.append('PAGEERROR '+str(e)))
        await pg.goto(URL); await pg.wait_for_selector('html.gl-on',timeout=20000); await pg.wait_for_timeout(2500)
        y=await pg.evaluate("(document.getElementById('top').offsetHeight-innerHeight)*0.30")
        await pg.evaluate(f"window.scrollTo({{top:{y},behavior:'instant'}})"); await pg.wait_for_timeout(1800)
        # buscar una foto bajo algún punto de la pantalla
        hit=None
        for (x,yy) in [(300,300),(800,300),(550,330),(250,380),(850,380),(700,250),(400,250),(200,250),(900,250)]:
            ok=await pg.evaluate(f"!!window.__sky().pick({x},{yy})")
            if ok: hit=(x,yy); break
        print('foto encontrada en', hit)
        if hit:
            await pg.mouse.click(*hit); await pg.wait_for_timeout(2600)
            print('ficha abierta:', await pg.evaluate("document.getElementById('piece').classList.contains('on')"), '|', await pg.inner_text('#piece-n'), '|', await pg.inner_text('#piece-t'))
            await pg.screenshot(path='/tmp/shots/i_foco.png')
            await pg.click('#piece-close'); await pg.wait_for_timeout(600)
            print('ficha cerrada:', not await pg.evaluate("document.getElementById('piece').classList.contains('on')"))
        # teclas: flecha derecha salta de escena
        s0=await pg.evaluate("scrollY"); await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(700)
        print('flecha derecha avanza:', (await pg.evaluate("scrollY"))>s0, '| escena:', await pg.inner_text('#bar-idx'))
        # hoja de contactos y foto ampliada
        await pg.evaluate("document.querySelector('#contactos').scrollIntoView()"); await pg.wait_for_timeout(700)
        await pg.click('.fr[data-k="08"]'); await pg.wait_for_timeout(700)
        print('ampliada abierta:', not await pg.evaluate("document.getElementById('lb').hidden"), '|', await pg.inner_text('#lb-n'))
        await pg.screenshot(path='/tmp/shots/i_lb.png')
        await pg.keyboard.press('ArrowRight'); await pg.wait_for_timeout(300); print('siguiente:', await pg.inner_text('#lb-n'))
        await pg.keyboard.press('Escape'); await pg.wait_for_timeout(300); print('ampliada cerrada:', await pg.evaluate("document.getElementById('lb').hidden"))
        print('nav visible tras el viaje:', await pg.evaluate("document.getElementById('nav').classList.contains('solid')"))
        print('enlace whatsapp:', await pg.get_attribute('.book-cta [data-wa]','href'))
        for e in errs[:10]: print('  consola:', e[:240])
        print('errores de consola:', len(errs))
        await b.close()
asyncio.run(main())
