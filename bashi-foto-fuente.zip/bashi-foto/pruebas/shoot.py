#!/usr/bin/env python3
"""Usage: shoot.py <name> <w> <h> <pos,pos,...> [--touch] [--cols N]
pos: 'hNN' = NN% of the hero journey, '#id' = scroll to element top (+offset with '#id+300'),
     '#id@0.5' = element top + 0.5*element height - used for the horizontal obra section
"""
import sys, asyncio, math
from playwright.async_api import async_playwright
from PIL import Image

import os
URL = "http://localhost:8765/index.html?snap" + os.environ.get("QS", "")

async def main():
    name, w, h = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    poss = sys.argv[4].split(',')
    touch = '--touch' in sys.argv
    cols = int(sys.argv[sys.argv.index('--cols')+1]) if '--cols' in sys.argv else 4
    async with async_playwright() as p:
        b = await p.chromium.launch(args=['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'])
        ctx = await b.new_context(viewport={'width': w, 'height': h}, device_scale_factor=1, has_touch=touch, is_mobile=touch)
        page = await ctx.new_page()
        errs = []
        page.on('console', lambda m: errs.append(m.text) if m.type in ('error', 'warning') else None)
        page.on('pageerror', lambda e: errs.append('PAGEERROR ' + str(e)))
        await page.goto(URL)
        try:
            await page.wait_for_selector('html.ready', timeout=15000)
        except Exception as e:
            errs.append('ready timeout')
        try:
            await page.wait_for_selector('html.gl-on', timeout=20000)
        except Exception as e:
            errs.append('sky-on timeout')
        await page.wait_for_timeout(4000)
        shots = []
        for pos in poss:
            if pos.startswith('h'):
                frac = float(pos[1:]) / 100
                y = await page.evaluate(f"(document.getElementById('top').offsetHeight - innerHeight) * {frac}")
            else:
                sel, off, fr = pos, 0, 0
                if '@' in sel: sel, fr = sel.split('@'); fr = float(fr)
                if '+' in sel: sel, off = sel.split('+'); off = int(off)
                y = await page.evaluate(f"(()=>{{const e=document.querySelector('{sel}');const r=e.getBoundingClientRect();return r.top+scrollY+{off}+r.height*{fr};}})()")
            await page.evaluate(f"window.scrollTo({{top:{y},behavior:'instant'}})")
            await page.wait_for_timeout(1500)
            fn = f"/tmp/shots/{name}_{pos.replace('#','').replace('@','_').replace('+','_')}.png"
            await page.screenshot(path=fn)
            shots.append(fn)
        info = await page.evaluate("({sw:document.documentElement.scrollWidth, iw:innerWidth, sh:document.documentElement.scrollHeight})")
        print('page', info, '| h-overflow:', info['sw'] > info['iw'])
        for e in errs[:12]: print('  console:', e[:300])
        await b.close()
    ims = [Image.open(s).convert('RGB') for s in shots]
    scale = min(1.0, 620 / w) if w > h else min(1.0, 330 / w)
    ims = [im.resize((round(im.width*scale), round(im.height*scale)), Image.LANCZOS) for im in ims]
    rows = math.ceil(len(ims) / cols)
    cw, ch = ims[0].size
    sheet = Image.new('RGB', (cols*cw + (cols-1)*6, rows*ch + (rows-1)*6), (255, 0, 255))
    for i, im in enumerate(ims):
        sheet.paste(im, ((i % cols)*(cw+6), (i//cols)*(ch+6)))
    out = f"/tmp/shots/{name}_sheet.jpg"
    sheet.save(out, quality=82)
    print('sheet', out, sheet.size)

asyncio.run(main())
