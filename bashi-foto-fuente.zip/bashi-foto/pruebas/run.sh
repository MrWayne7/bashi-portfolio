#!/bin/bash
# uso: ./run.sh <args de shoot.py>   (levanta el server, toma capturas, lo apaga)
D="$(cd "$(dirname "$0")/.." && pwd)"
cd "$D/dist/test" && python3 -m http.server 8765 >/tmp/http.log 2>&1 &
SP=$!
sleep 0.8
mkdir -p /tmp/shots
cd "$D/pruebas" && timeout 285 python3 shoot.py "$@" 2>&1 | tail -14
kill $SP 2>/dev/null
