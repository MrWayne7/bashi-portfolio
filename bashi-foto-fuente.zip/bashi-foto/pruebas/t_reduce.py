import asyncio
from playwright.async_api import async_playwright
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch(args=['--use-gl=angle','--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
        ctx=await b.new_context(viewport={'width':900,'height':600}, reduced_motion='reduce')
        pg=await ctx.new_page(); errs=[]
        pg.on('console', lambda m: errs.append(m.text) if m.type in ('error','warning') else None)
        pg.on('pageerror', lambda e: errs.append('PAGEERROR '+str(e)))
        await pg.goto("http://localhost:8765/index.html?q=mid"); await pg.wait_for_selector('html.gl-on',timeout=20000); await pg.wait_for_timeout(1500)
        for f in (0.1,0.36,0.6,0.9,1.0):
            await pg.evaluate(f"window.scrollTo(0,(document.getElementById('top').offsetHeight-innerHeight)*{f})"); await pg.wait_for_timeout(900)
        print('movimiento reducido: escena', await pg.inner_text('#bar-idx'), '| fotograma', await pg.inner_text('#osd-n'), '| errores:', len(errs))
        for e in errs[:6]: print('  ', e[:200])
        # sin WebGL: debe quedar la portada y el contenido
        ctx2=await b.new_context(viewport={'width':900,'height':600}); pg2=await ctx2.new_page()
        await pg2.add_init_script("HTMLCanvasElement.prototype.getContext=function(){return null}")
        await pg2.goto("http://localhost:8765/index.html"); await pg2.wait_for_timeout(5000)
        print('sin WebGL -> clase gl-off:', await pg2.evaluate("document.documentElement.classList.contains('gl-off')"), '| alto del héroe (px):', await pg2.evaluate("document.getElementById('top').offsetHeight"))
        await b.close()
asyncio.run(main())
