Promise.all([fontsReady, Promise.race([gsapReady, new Promise(function(r){ setTimeout(r, 1400); })])]).then(finishLoader);
if (SNAP) window.__sky = function(){ return SKY; };   // solo para pruebas

/* ============================================================
   El visor: escenas, barra, contador de fotogramas, obturador
   ============================================================ */
(function(){
  var NS = SC.length;
  var nav = $('#nav'), ui = $('#hero-ui'), title = $('#hero-title'), hint = $('#hint');
  var cap = $('#cap'), capT = $('#cap-t'), capS = $('#cap-s'), idx = $('#bar-idx'), fill = $('#bar-fill');
  var oSc = $('#osd-sc'), oPl = $('#osd-place'), oF = $('#osd-f'), oN = $('#osd-n'), oTc = $('#osd-tc'), oDate = $('#osd-date'), shutter = $('#shutter');
  var cur = -1, swapping = false, tm = 0, lastP = -1, lastSolid = null, lastShot = -1, lastF = '', lastTc = null;
  var gyRow = $('.gyro-row');

  /* fecha quemada, como en una videocámara */
  (function(){
    var M = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SEP', 'OCT', 'NOV', 'DIC'];
    function tick(){ var d = new Date(); if (oDate) oDate.textContent = pad2(d.getDate()) + ' ' + M[d.getMonth()] + ' ' + d.getFullYear() + '  ' + pad2(d.getHours()) + ':' + pad2(d.getMinutes()); }
    tick(); setInterval(tick, 20000);
  })();

  /* las marcas de la barra van donde empieza cada escena y se pueden tocar para saltar */
  var line = $('.bar-line');
  function yOf(i){ return i ? (unmap(CHU[i]) + 0.004) * heroMax : 0; }
  if (line){
    SC.forEach(function(c, i){
      if (!i) return;
      var b = document.createElement('button'); b.type = 'button'; b.className = 'bar-tick'; b.style.left = (unmap(CHU[i]) * 100).toFixed(2) + '%';
      b.setAttribute('aria-label', 'Ir a la escena ' + (i + 1) + ': ' + c[1]);
      b.addEventListener('click', function(){ goTo(yOf(i)); });
      line.appendChild(b);
    });
  }
  /* flechas: escena anterior / siguiente */
  document.addEventListener('keydown', function(e){
    if (window.scrollY > heroMax || (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft')) return;
    if (document.documentElement.classList.contains('lb-open')) return;
    goTo(yOf(clamp(cur + (e.key === 'ArrowRight' ? 1 : -1), 0, NS - 1)));
  });

  tickers.push(function(){
    var p = S.p, u = S.u, y = window.scrollY;
    var solid = y > heroMax + 4;
    if (solid !== lastSolid){ nav.classList.toggle('solid', solid); lastSolid = solid; }
    if (y > heroMax + window.innerHeight) return;

    /* lecturas del visor: cambian aunque el scroll esté quieto */
    if (S.shot !== lastShot && oN){ lastShot = S.shot; oN.textContent = pad2(S.shot || 0); }
    if (S.fstop !== lastF && oF){ lastF = S.fstop; oF.textContent = 'f/' + (S.fstop || '1.4'); }
    if (S.tc !== lastTc && oTc){ lastTc = S.tc; oTc.textContent = S.tc || ''; }

    if (Math.abs(p - lastP) < 0.00002 && cur !== -1) return;
    lastP = p;
    /* el título se desenfoca al entrar por el lente */
    var tOut = sstep(0.004, 0.022, u);
    title.style.opacity = (1 - tOut).toFixed(3);
    title.style.filter = tOut > 0.001 && tOut < 0.999 ? 'blur(' + (tOut * 16).toFixed(1) + 'px)' : 'none';
    title.style.visibility = tOut > 0.999 ? 'hidden' : 'visible';
    if (gyRow){ var go = 1 - sstep(0.004, 0.02, u); gyRow.style.opacity = go.toFixed(3); gyRow.style.pointerEvents = go < 0.1 ? 'none' : ''; }
    hint.style.opacity = (1 - sstep(0.001, 0.012, p)).toFixed(3);
    ui.style.opacity = (1 - sstep(0.975, 0.995, u)).toFixed(3);
    fill.style.transform = 'scaleX(' + p.toFixed(4) + ')';

    var a = 0; for (var i = 0; i < NS; i++){ if (u >= CHU[i]) a = i; }
    var want = u > 0.02 && u < 0.985;
    if (a !== cur){
      if (cur !== -1 && shutter && !reduce){ shutter.classList.remove('snap'); void shutter.offsetWidth; shutter.classList.add('snap'); }   // golpe de obturador
      cur = a; S.sc = a; swapping = true; cap.classList.remove('on'); clearTimeout(tm);
      tm = setTimeout(function(){
        capT.textContent = SC[cur][1]; capS.textContent = SC[cur][2];
        if (oSc) oSc.textContent = 'ESC ' + pad2(cur + 1);
        if (oPl) oPl.textContent = SC[cur][3];
        idx.textContent = pad2(cur + 1) + ' / ' + pad2(NS);
        swapping = false; lastP = -1;
      }, 200);
    }
    if (!swapping) cap.classList.toggle('on', want);
    ui.classList.toggle('go', want);
  });
})();

/* ============================================================
   Tocar una foto del viaje: la cámara vuela hasta ella y sale su ficha
   ============================================================ */
(function(){
  var ui = $('#hero-ui'), panel = $('#piece'); if (!panel || !ui) return;
  var pn = $('#piece-n'), pt = $('#piece-t'), pd = $('#piece-d'), cur = $('#cur');
  var open = false, y0 = 0, hov = false, fc = 0;
  function close(){
    if (!open) return; open = false;
    panel.classList.remove('on'); ui.classList.remove('focus');
    if (SKY) SKY.unfocus();
  }
  function show(info){
    pn.textContent = info.n + ' / 36'; pt.textContent = info.title; pd.textContent = info.desc; pd.hidden = !info.desc;
    panel.classList.add('on'); ui.classList.add('focus'); open = true; y0 = window.scrollY;
  }
  hero.addEventListener('click', function(e){
    if (!SKY || (e.target.closest && e.target.closest('a,button'))) return;
    var info = SKY.focus(e.clientX, e.clientY);
    if (info) show(info); else close();
  });
  $('#piece-close').addEventListener('click', close);
  $('#piece-go').addEventListener('click', close);
  document.addEventListener('keydown', function(e){ if (e.key === 'Escape') close(); });
  window.addEventListener('scroll', function(){ if (open && Math.abs(window.scrollY - y0) > 70) close(); }, { passive: true });
  if (finePointer) tickers.push(function(){
    if (!SKY || !S.moved || (fc++) % 4) return;
    var h = window.scrollY < heroMax && !open && !!SKY.pick(S.cx, S.cy);
    if (h === hov) return; hov = h;
    ui.style.cursor = h ? 'pointer' : '';
    if (cur) cur.classList.toggle('see', h);
  });
})();

/* ============================================================
   Hoja de contactos: tocar un fotograma lo abre en grande
   ============================================================ */
(function(){
  var lb = $('#lb'); if (!lb) return;
  var img = $('#lb-img'), ln = $('#lb-n'), lt = $('#lb-t'), frames = $$('.fr'), at = 0, back = null;
  function set(i){
    at = (i + frames.length) % frames.length;
    var f = frames[at], k = f.getAttribute('data-k'), m = META[k] || {};
    img.src = f.getAttribute('data-big'); img.alt = $('img', f).alt;
    ln.textContent = k + ' / 36'; lt.textContent = m.t || escenaDe(k);
  }
  function open(i, from){
    back = from || null; set(i);
    lb.hidden = false; document.documentElement.classList.add('lb-open');
    if (lenis) lenis.stop();
    $('#lb-close').focus();
  }
  function close(){
    if (lb.hidden) return;
    lb.hidden = true; document.documentElement.classList.remove('lb-open');
    if (lenis) lenis.start();
    if (back) back.focus();
  }
  frames.forEach(function(f, i){ f.addEventListener('click', function(){ open(i, f); }); });
  $('#lb-close').addEventListener('click', close);
  $('#lb-prev').addEventListener('click', function(){ set(at - 1); });
  $('#lb-next').addEventListener('click', function(){ set(at + 1); });
  lb.addEventListener('click', function(e){ if (e.target === lb) close(); });
  document.addEventListener('keydown', function(e){
    if (lb.hidden) return;
    if (e.key === 'Escape') close(); else if (e.key === 'ArrowLeft') set(at - 1); else if (e.key === 'ArrowRight') set(at + 1);
  });
})();

/* ============================================================
   Cursor (solo puntero fino)
   ============================================================ */
(function(){
  if (!finePointer || reduce) return;
  var c = $('#cur'); if (!c) return;
  var x = 0, y = 0;
  tickers.push(function(){
    if (!S.moved) return;
    c.classList.add('on');
    x += (S.cx - x) * 0.22; y += (S.cy - y) * 0.22;
    c.style.transform = 'translate3d(' + x.toFixed(1) + 'px,' + y.toFixed(1) + 'px,0)';
  });
  document.addEventListener('pointerover', function(e){
    var hit = e.target.closest && e.target.closest('a,button,.fr,.piece');
    c.classList.toggle('big', !!hit);
  });
  document.addEventListener('pointerleave', function(){ c.classList.remove('on'); });
})();

/* ============================================================
   Entrada: un solo momento orquestado, el nombre sube letra por letra
   ============================================================ */
function intro(){
  if (!window.gsap || reduce) return;
  var g = window.gsap;
  g.from('.hero-title h1 span', { yPercent: 110, duration: 1.1, ease: 'power4.out', stagger: 0.06 });
  g.from('.hero-title .sub > *', { y: 16, autoAlpha: 0, duration: 0.9, ease: 'power3.out', stagger: 0.12, delay: 0.5 });
}

/* ---------- bucle único ---------- */
(function loop(now){ for (var i = 0; i < tickers.length; i++){ try { tickers[i](now); } catch (e) { console.error(e); } } requestAnimationFrame(loop); })(performance.now());

})();
