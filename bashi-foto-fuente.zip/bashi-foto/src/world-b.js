
  /* ============ 6. NUEVA YORK: torres, vapor, carteles y el tren elevado ============ */
  var train = new THREE.Group(), spark = null, steam = [], nyPhotos = [];
  (function(){
    var g = grp(5);
    /* la ciudad vista desde arriba: una alfombra de luces */
    var carpet = [], i;
    for (i = 0; i < (tier ? 900 : 400); i++){
      var gx = Math.round(rr(-12, 12)) * 6.2 + rr(-0.5, 0.5), gz = -236 - rnd() * 100;
      if (rnd() < 0.5) gx = rr(-74, 74), gz = -236 - Math.round(rnd() * 16) * 6.2;
      if (Math.abs(gx) < 5) continue;
      pushPt(carpet, gx, Y0 + 0.2, gz, rnd() < 0.7 ? 0xffb060 : 0xdfe8ff, rr(0.4, 1));
    }
    g.add(pts(carpet, 0.75));
    var towerT = cv(128, 256, function(x){
      x.fillStyle = '#06070a'; x.fillRect(0, 0, 128, 256);
      for (var r = 0; r < 18; r++){ for (var c = 0; c < 7; c++){
        var lit = rnd() < 0.3;
        x.fillStyle = lit ? (rnd() < 0.6 ? 'rgba(255,212,154,' : 'rgba(201,220,255,') + rr(0.35, 1).toFixed(2) + ')' : '#0c0f14';
        x.fillRect(6 + c * 17.2, 5 + r * 14, 11, 8);
      } }
    }, [2, 3]);
    var tg = new THREE.BoxGeometry(1, 1, 1); tg.translate(0, 0.5, 0);
    var sideM = new THREE.MeshBasicMaterial({ map: towerT }), topM = basic(0x050608);
    var defs = [];
    for (var z = -238; z > -302; z -= 6.4){ [-1, 1].forEach(function(sd){ defs.push({ sd: sd, gap: 5.6, w: rr(4, 7), d: rr(5, 6.2), h: rr(9, 24), z: z + rr(-0.5, 0.5) }); }); }
    for (i = 0; i < 22; i++){ defs.push({ sd: i % 2 ? 1 : -1, gap: rr(15, 40), w: rr(5, 9), d: rr(5, 9), h: rr(14, 34), z: rr(-330, -236) }); }
    var towers = new THREE.InstancedMesh(tg, [sideM, sideM, topM, topM, sideM, sideM], defs.length), dm = new THREE.Object3D();
    defs.forEach(function(d, n){ towers.setColorAt(n, new THREE.Color().setHSL(rr(0.55, 0.62), 0.25, rr(0.42, 0.7))); });
    respread.push(function(){
      defs.forEach(function(d, n){
        var gap = d.gap < 10 ? d.gap * lerp(0.5, 1, kR) : d.gap;
        dm.position.set(d.sd * (gap + d.w / 2), Y0, d.z); dm.scale.set(d.w, d.h, d.d); dm.updateMatrix(); towers.setMatrixAt(n, dm.matrix);
      });
      towers.instanceMatrix.needsUpdate = true;
    });
    towers.frustumCulled = false; g.add(towers);
    var stT = cv(128, 256, function(x){
      x.fillStyle = '#0a0b0e'; x.fillRect(0, 0, 128, 256);
      for (var n = 0; n < 420; n++){ x.fillStyle = 'rgba(255,255,255,' + (rnd() * 0.04).toFixed(3) + ')'; x.fillRect(rnd() * 128, rnd() * 256, 1.5, 1.5); }
      x.fillStyle = 'rgba(232,234,238,0.7)'; x.fillRect(61, 30, 6, 90);
      var gr = x.createLinearGradient(0, 0, 128, 0); gr.addColorStop(0, 'rgba(120,150,200,0.1)'); gr.addColorStop(0.5, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(255,170,90,0.1)'); x.fillStyle = gr; x.fillRect(0, 0, 128, 256);
    }, [1, 9]);
    var st = floor(11, 74, new THREE.MeshBasicMaterial({ map: stT }), 0, Y0, -267); g.add(st);
    respread.push(function(){ st.scale.x = lerp(0.52, 1, kR); });
    lamp(g, -4.7, -252, 0xff9d3c, 5); lamp(g, 4.7, -266, 0xff9d3c, 5); lamp(g, -4.7, -281, 0xff9d3c, 5); lamp(g, 4.7, -295, 0xff9d3c, 5);
    /* vapor de las alcantarillas */
    [[-1.4, -250], [1.8, -262], [-0.8, -277], [1.2, -291]].forEach(function(e){
      for (var n = 0; n < 3; n++){
        var s = new THREE.Sprite(new THREE.SpriteMaterial({ map: softT, color: 0xb6c2d0, transparent: true, opacity: 0, depthWrite: false, fog: false }));
        s.userData = { x: e[0], z: e[1], ph: n / 3 + rnd() * 0.2 }; g.add(s); steam.push(s);
      }
    });
    /* tablones de obra con los carteles: fotos 13–18 */
    var hoardT = cv(256, 256, function(x){
      x.fillStyle = '#0b2418'; x.fillRect(0, 0, 256, 256);
      x.strokeStyle = '#081a11'; x.lineWidth = 3; [64, 128, 192].forEach(function(px){ x.beginPath(); x.moveTo(px, 0); x.lineTo(px, 256); x.stroke(); });
      x.fillStyle = 'rgba(232,236,228,0.8)'; x.font = '700 25px ' + F_CON; x.textAlign = 'center'; x.fillText('P O S T   N O   B I L L S', 128, 28);
    });
    for (i = 0; i < 6; i++){
      var sd = i % 2 ? 1 : -1, hg = new THREE.Group();
      var pn = plane(3.9, 3.7, new THREE.MeshBasicMaterial({ map: hoardT })); pn.position.set(0, 0.55, -0.04); hg.add(pn);
      var f = addPhoto(hg, pad2(i + 13), 2.45, { border: 0.1, maxW: 3.1 }); f.position.y = 0.35; f.rotation.z = rr(-0.05, 0.05);
      hg.position.set(0, 0, -248 - i * 8.2); hg.rotation.y = -sd * 0.58;
      g.add(hg); place(hg, sd * 3.55, 1); nyPhotos.push(f);
    }
    /* malla metálica */
    var fenceT = cv(64, 64, function(x){ x.strokeStyle = 'rgba(150,162,176,0.9)'; x.lineWidth = 2; x.beginPath(); x.moveTo(0, 0); x.lineTo(64, 64); x.moveTo(64, 0); x.lineTo(0, 64); x.moveTo(-32, 32); x.lineTo(32, 96); x.moveTo(32, -32); x.lineTo(96, 32); x.stroke(); }, [30, 6]);
    var fence = plane(20, 3.0, new THREE.MeshBasicMaterial({ map: fenceT, transparent: true, side: THREE.DoubleSide, depthWrite: false }));
    fence.rotation.y = PI / 2; fence.position.set(0, Y0 + 1.5, -289); g.add(fence); place(fence, -4.5, 0);
    /* taxi amarillo estacionado */
    var taxi = new THREE.Group();
    var tb = box(1.7, 0.62, 3.9, basic(0xd9a80f)); tb.position.y = Y0 + 0.62; taxi.add(tb);
    var tc = box(1.5, 0.5, 1.9, basic(0x0b0c10)); tc.position.set(0, Y0 + 1.15, -0.1); taxi.add(tc);
    var tr = box(0.5, 0.16, 0.2, basic(0xfff2b0, { fog: false })); tr.position.set(0, Y0 + 1.48, -0.1); taxi.add(tr);
    [-0.6, 0.6].forEach(function(px){ var l = glow(0xff1a1a, 1.1, 1); l.position.set(px, Y0 + 0.7, 1.98); taxi.add(l); });
    taxi.position.z = -299.5; g.add(taxi); place(taxi, -3.0, 0);
    /* el tren elevado */
    var steel = basic(0x0b0f15);
    [-269.2, -270.8].forEach(function(bz){ var b = box(90, 0.5, 0.7, steel); b.position.set(0, 5.7, bz); g.add(b); });
    [-1, 1].forEach(function(sd){ var c = box(0.55, 7, 0.55, steel); c.position.set(0, Y0 + 3.5, -270); g.add(c); place(c, sd * 5.0, 0); });
    var winT = cv(256, 64, function(x){ x.fillStyle = '#12161c'; x.fillRect(0, 0, 256, 64); x.fillStyle = '#ffe9b8'; for (var n = 0; n < 6; n++){ x.fillRect(10 + n * 41, 14, 32, 26); } x.fillStyle = '#8f1820'; x.fillRect(0, 50, 256, 6); });
    for (i = 0; i < 4; i++){
      var car = box(7.2, 1.9, 1.5, [basic(0x12161c), basic(0x12161c), basic(0x0c0f14), basic(0x07090c), new THREE.MeshBasicMaterial({ map: winT, fog: false }), basic(0x12161c)]);
      car.position.x = i * 7.5; train.add(car);
    }
    train.position.set(0, 6.95, -270); g.add(train);
    spark = glow(0xbfe0ff, 9, 0); spark.position.set(0, 5.6, -270); g.add(spark);
  })();

  /* ============ 7. MIAMI: neón, palmeras, vallas y el asfalto mojado ============ */
  var car = new THREE.Group();
  (function(){
    var g = grp(6);
    /* el piso deja ver lo que hay debajo: ahí van los reflejos */
    g.add(floor(90, 66, new THREE.MeshBasicMaterial({ color: 0x07030d, transparent: true, opacity: 0.74 }), 0, Y0, -330));
    var palmT = cv(256, 512, function(x){
      x.lineCap = 'round';
      x.strokeStyle = '#150b1f'; x.lineWidth = 15; x.beginPath(); x.moveTo(118, 512); x.quadraticCurveTo(100, 300, 132, 150); x.stroke();
      x.strokeStyle = '#5a1f5f'; x.lineWidth = 2.5; x.beginPath(); x.moveTo(126, 512); x.quadraticCurveTo(108, 300, 140, 150); x.stroke();
      for (var i = 0; i < 13; i++){
        var a = -PI * 0.5 + (i - 6) * 0.42 + rr(-0.08, 0.08), len = rr(96, 128), ex = 132 + Math.cos(a) * len, ey = 150 + Math.sin(a) * len * 0.72 + Math.abs(i - 6) * 9;
        x.strokeStyle = '#1b0f28'; x.lineWidth = 9; x.beginPath(); x.moveTo(132, 150); x.quadraticCurveTo(132 + Math.cos(a) * len * 0.55, 150 + Math.sin(a) * len * 0.9 - 26, ex, ey); x.stroke();
        x.strokeStyle = '#6a2470'; x.lineWidth = 1.8; x.beginPath(); x.moveTo(132, 148); x.quadraticCurveTo(132 + Math.cos(a) * len * 0.55, 148 + Math.sin(a) * len * 0.9 - 28, ex, ey - 2); x.stroke();
      }
    });
    var pg = new THREE.PlaneGeometry(1, 1); pg.translate(0, 0.5, 0);
    var pdef = []; for (var i = 0; i < 14; i++){ pdef.push({ sd: i % 2 ? 1 : -1, x: rr(5.4, 7.6), z: -303 - i * 4.2 + rr(-1, 1), h: rr(7.2, 10), fl: rnd() < 0.5 ? -1 : 1 }); }
    var palms = new THREE.InstancedMesh(pg, new THREE.MeshBasicMaterial({ map: palmT, transparent: true, alphaTest: 0.35, side: THREE.DoubleSide }), pdef.length), dm = new THREE.Object3D();
    respread.push(function(){
      pdef.forEach(function(p, n){ dm.position.set(p.sd * p.x * lerp(0.5, 1, kR), Y0, p.z); dm.scale.set(p.h * 0.5 * p.fl, p.h, 1); dm.updateMatrix(); palms.setMatrixAt(n, dm.matrix); });
      palms.instanceMatrix.needsUpdate = true;
    });
    palms.frustumCulled = false; g.add(palms);
    /* edificios bajos con filos de neón */
    var MAG = 0xff2fa0, CYA = 0x19e3ff;
    [[-1, -312, 5.2, MAG], [1, -322, 6.4, CYA], [-1, -336, 4.6, CYA], [1, -346, 5.6, MAG], [-1, -356, 6.2, MAG]].forEach(function(e){
      var bg2 = new THREE.Group(), w = 9, d = 9;
      var b = box(w, e[2], d, basic(0x0c0614)); b.position.y = Y0 + e[2] / 2; bg2.add(b);
      [e[2], e[2] * 0.62].forEach(function(h, n){ var s = box(0.07, 0.07, d + 0.1, basic(n ? (e[3] === MAG ? CYA : MAG) : e[3], { fog: false })); s.position.set(-e[0] * (w / 2 + 0.03), Y0 + h, 0); bg2.add(s); });
      var s2 = box(w + 0.1, 0.07, 0.07, basic(e[3], { fog: false })); s2.position.set(0, Y0 + e[2], d / 2 + 0.03); bg2.add(s2);
      bg2.position.z = e[1]; g.add(bg2); place(bg2, e[0] * 13.5, 0);
    });
    /* letreros de neón; cada uno lleva una copia invertida bajo el piso, que es su reflejo */
    [['CALLE 8', '#ff2fa0', -1, -317, 3.3, 1.5], ['FOTO', '#19e3ff', 1, -331, 3.0, 1.7], ['ABIERTO 24 H', '#ff2fa0', 1, -351, 3.6, 1.15], ['305', '#19e3ff', -1, -343, 3.1, 1.6]].forEach(function(e){
      var ng = new THREE.Group(), t = textPlane([e[0]], e[5], { glow: true, color: e[1], weight: 700, size: 150 });
      t.position.y = e[4] - Y0; ng.add(t);
      var mm = new THREE.Group(); mm.scale.y = -1; mm.add(t.clone()); ng.add(mm);
      ng.position.set(0, Y0, e[3]); ng.rotation.y = -e[2] * 0.42; g.add(ng); place(ng, e[2] * 6.2, 1, true);
    });
    /* vallas con las fotos 19–23 y su reflejo */
    for (i = 0; i < 5; i++){
      var sd = i % 2 ? -1 : 1, vg = new THREE.Group(), py = 2.75;
      var f = addPhoto(vg, pad2(i + 19), 2.5, { border: 0.1, borderColor: 0x0a0a0d, maxW: 3.4 }), fu = f.userData; f.position.y = py;
      var legH = py - fu.h / 2;
      [-0.9, 0.9].forEach(function(px){ var p = box(0.12, legH, 0.12, basic(0x0a0a0d)); p.position.set(px, legH / 2, -0.1); vg.add(p); });
      var m = new THREE.Group(); m.scale.y = -1;
      var cl = plane(fu.w, fu.h, fu.mat); cl.position.y = py; m.add(cl);
      var fr = plane(fu.w + 0.2, fu.h + 0.2, basic(0x0a0a0d)); fr.position.set(0, py, -0.015); m.add(fr);
      vg.add(m);
      [-1, 1].forEach(function(s3){ var l = glow(0xfff0d0, 0.9, 0.7); l.position.set(s3 * fu.w * 0.3, py + fu.h / 2 + 0.2, 0.2); vg.add(l); });
      vg.position.set(0, Y0, -309 - i * 9.6); vg.rotation.y = -sd * 0.5;
      g.add(vg); place(vg, sd * 3.75, 1, true);
    }
    /* un carro adelante, con luz bajo el chasis */
    var cb = box(1.85, 0.48, 4.3, basic(0x060609)); cb.position.y = Y0 + 0.5; car.add(cb);
    var cc = box(1.6, 0.42, 2.0, basic(0x040406)); cc.position.set(0, Y0 + 0.93, 0.1); car.add(cc);
    [-0.68, 0.68].forEach(function(px){ var l = glow(0xff1a1a, 1.3, 1); l.position.set(px, Y0 + 0.58, 2.2); car.add(l); });
    var ug = floor(3.6, 6.4, new THREE.MeshBasicMaterial({ map: softT, color: 0xff2fa0, transparent: true, opacity: 0.85, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }), 0, Y0 + 0.03, 0); car.add(ug);
    car.visible = false; g.add(car);
  })();

  /* ============ 8. ATLANTA: la cabina, luz roja y el bajo ============ */
  var woofers = [];
  (function(){
    var g = grp(7);
    var dark = basic(0x050203);
    /* la puerta: se entra a la cabina */
    [-1, 1].forEach(function(sd){
      var wall = box(20, 9, 0.4, dark); wall.position.set(0, 2.4, -362); g.add(wall);
      respread.push(function(){ wall.position.x = sd * (10 + 2.3 * lerp(0.62, 1, kR)); });
    });
    var lintel = box(26, 3, 0.4, dark); lintel.position.set(0, 5.6, -362); g.add(lintel);
    var onair = textPlane(['ON AIR'], 0.95, { glow: true, color: '#ff2020', weight: 700, size: 150 }); onair.position.set(0, 3.25, -361.7); g.add(onair);
    var foamT = cv(64, 64, function(x){
      x.fillStyle = '#120406'; x.fillRect(0, 0, 64, 64);
      [[0, 0], [32, 0], [0, 32], [32, 32]].forEach(function(o){
        x.fillStyle = '#2b090c'; x.beginPath(); x.moveTo(o[0], o[1]); x.lineTo(o[0] + 32, o[1]); x.lineTo(o[0] + 16, o[1] + 16); x.fill();
        x.fillStyle = '#0c0304'; x.beginPath(); x.moveTo(o[0], o[1] + 32); x.lineTo(o[0] + 32, o[1] + 32); x.lineTo(o[0] + 16, o[1] + 16); x.fill();
        x.fillStyle = '#1c0608'; x.beginPath(); x.moveTo(o[0], o[1]); x.lineTo(o[0], o[1] + 32); x.lineTo(o[0] + 16, o[1] + 16); x.fill();
      });
    }, [20, 3]);
    [-1, 1].forEach(function(sd){
      var w = plane(46, 6.2, new THREE.MeshBasicMaterial({ map: foamT })); w.rotation.y = -sd * PI / 2; w.position.set(0, Y0 + 3.1, -386);
      var led = box(0.06, 0.06, 46, basic(0xff1a1a, { fog: false })); led.position.set(-sd * 0.05, Y0 + 6.1, -386);
      var wg = new THREE.Group(); wg.add(w); wg.add(led); g.add(wg); place(wg, sd * 4.5, 0);
    });
    g.add(floor(12, 48, basic(0x0c0304), 0, Y0, -386));
    var ceil = plane(12, 48, basic(0x060203)); ceil.rotation.x = PI / 2; ceil.position.set(0, Y0 + 6.25, -386); g.add(ceil);
    /* monitores de estudio */
    var coneTx = cv(128, 128, function(x){
      var gr = x.createRadialGradient(64, 64, 4, 64, 64, 64); gr.addColorStop(0, '#2a2a2e'); gr.addColorStop(0.22, '#0d0d0f'); gr.addColorStop(0.24, '#1e1e22'); gr.addColorStop(0.8, '#0a0a0c'); gr.addColorStop(0.86, '#3a3a40'); gr.addColorStop(1, '#101012');
      x.fillStyle = gr; x.beginPath(); x.arc(64, 64, 64, 0, TAU); x.fill();
    });
    [[-1, -371], [1, -379], [-1, -390], [1, -401]].forEach(function(e){
      var sg = new THREE.Group();
      var cab = box(1.5, 2.9, 1.1, basic(0x0b0b0d)); cab.position.y = Y0 + 1.45; sg.add(cab);
      var w1 = new THREE.Mesh(new THREE.CircleGeometry(0.56, 32), new THREE.MeshBasicMaterial({ map: coneTx })); w1.position.set(0, Y0 + 1.0, 0.56); sg.add(w1); woofers.push(w1);
      var w2 = new THREE.Mesh(new THREE.CircleGeometry(0.22, 24), new THREE.MeshBasicMaterial({ map: coneTx })); w2.position.set(0, Y0 + 2.25, 0.56); sg.add(w2);
      var dot = glow(0xff2020, 0.3, 1); dot.position.set(0.55, Y0 + 2.7, 0.58); sg.add(dot);
      sg.position.z = e[1]; sg.rotation.y = -e[0] * 0.85; g.add(sg); place(sg, e[0] * 3.5, 1);
    });
    /* pantallas con las fotos 24–28 */
    for (var i = 0; i < 5; i++){
      var sd = i % 2 ? -1 : 1, mg = new THREE.Group();
      var f = addPhoto(mg, pad2(i + 24), 1.95, { border: 0.09, borderColor: 0x030303, maxW: 2.9 }); f.position.y = 0.55 + (i % 3) * 0.22;
      var arm = box(0.07, 2.2, 0.07, basic(0x030303)); arm.position.set(0, -0.75, -0.08); mg.add(arm);
      var gl = glow(0xff2a2a, 5, 0.22); gl.position.set(0, 0.6, -0.4); mg.add(gl);
      mg.position.set(0, 0, -367.5 - i * 8.3); mg.rotation.y = -sd * 0.5;
      g.add(mg); place(mg, sd * 2.2, 1);
    }
    /* el micrófono con su filtro */
    var mic = new THREE.Group(), met = basic(0x1b1b1e);
    var stand = new THREE.Mesh(new THREE.CylinderGeometry(0.03, 0.03, 2.9, 8), met); stand.position.y = Y0 + 1.45; mic.add(stand);
    var boom = new THREE.Mesh(new THREE.CylinderGeometry(0.025, 0.025, 1.3, 8), met); boom.rotation.z = 1.1; boom.position.set(-0.5, Y0 + 3.05, 0); mic.add(boom);
    var cap = new THREE.Mesh(new THREE.CylinderGeometry(0.13, 0.11, 0.46, 16), basic(0x3a3a40)); cap.position.set(-1.05, Y0 + 2.95, 0); mic.add(cap);
    var popR = new THREE.Mesh(new THREE.TorusGeometry(0.3, 0.015, 6, 28), met); popR.position.set(-1.05, Y0 + 2.95, 0.36); mic.add(popR);
    var popD = new THREE.Mesh(new THREE.CircleGeometry(0.3, 28), new THREE.MeshBasicMaterial({ color: 0x000000, transparent: true, opacity: 0.55, depthWrite: false })); popD.position.copy(popR.position); mic.add(popD);
    mic.position.z = -394; g.add(mic); place(mic, 1.5, 1);
  })();

  /* ============ 9. LA MEZCLA: vuelve la niebla y la orquídea es de cromo ============ */
  var orchid = new THREE.Group(), ORCH_Z = -432;
  (function(){
    var g = grp(8);
    g.add(floor(90, 46, basic(0x060a09), 0, Y0, -430));
    /* cromo sin luces: un material que lleva el reflejo pintado */
    var matcap = cv(256, 256, function(x){
      var gr = x.createLinearGradient(0, 0, 0, 256);
      gr.addColorStop(0, '#f4fff8'); gr.addColorStop(0.28, '#8fa39a'); gr.addColorStop(0.47, '#1a211e'); gr.addColorStop(0.5, '#d8ffe9'); gr.addColorStop(0.56, '#3a4a43'); gr.addColorStop(0.8, '#0a0d0c'); gr.addColorStop(1, '#4d6a5c');
      x.fillStyle = gr; x.beginPath(); x.arc(128, 128, 128, 0, TAU); x.fill();
      var hl = x.createRadialGradient(84, 62, 2, 84, 62, 60); hl.addColorStop(0, 'rgba(255,255,255,0.95)'); hl.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = hl; x.fillRect(0, 0, 256, 256);
    });
    var chrome = new THREE.MeshMatcapMaterial({ matcap: matcap, side: THREE.DoubleSide, fog: false });
    function petal(L, W, curl, ruf){
      var nu = 12, nv = 8, pos = [], idx = [];
      for (var i = 0; i <= nu; i++){ for (var j = 0; j <= nv; j++){
        var u = i / nu, v = j / nv * 2 - 1, wd = Math.pow(Math.sin(PI * Math.min(1, u * 0.92 + 0.06)), 0.75) * W;
        pos.push(v * wd, u * L, curl * u * u * L - 0.35 * v * v * wd + ruf * Math.sin(u * 16 + v * 3) * u * Math.abs(v));
      } }
      for (i = 0; i < nu; i++){ for (j = 0; j < nv; j++){ var a = i * (nv + 1) + j, b = a + nv + 1; idx.push(a, b, a + 1, a + 1, b, b + 1); } }
      var ge = new THREE.BufferGeometry(); ge.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3)); ge.setIndex(idx); ge.computeVertexNormals();
      return ge;
    }
    var flower = new THREE.Group();
    var sep = petal(1.55, 0.3, -0.22, 0), pet = petal(1.35, 0.62, -0.12, 0.05), lip = petal(1.3, 0.78, 0.55, 0.12);
    [PI / 2, PI / 2 + TAU / 3, PI / 2 - TAU / 3].forEach(function(a){ var m = new THREE.Mesh(sep, chrome); m.rotation.z = a - PI / 2; m.position.z = -0.06; flower.add(m); });
    [0.55, -0.55].forEach(function(a){ var m = new THREE.Mesh(pet, chrome); m.rotation.z = a; flower.add(m); });
    var lp = new THREE.Mesh(lip, chrome); lp.rotation.z = PI; lp.rotation.x = -0.25; lp.position.z = 0.08; flower.add(lp);
    var col = new THREE.Mesh(new THREE.SphereGeometry(0.17, 16, 12), chrome); col.scale.set(1, 1.5, 1); col.position.set(0, -0.1, 0.2); flower.add(col);
    flower.position.y = 1.7; flower.rotation.x = -0.15; orchid.add(flower);
    var stem = new THREE.Mesh(new THREE.TubeGeometry(new THREE.CatmullRomCurve3([new THREE.Vector3(0.5, Y0, -0.3), new THREE.Vector3(0.25, -0.2, -0.25), new THREE.Vector3(-0.15, 0.9, -0.15), new THREE.Vector3(0, 1.62, -0.05)]), 24, 0.045, 8), chrome);
    orchid.add(stem);
    var halo = glow(0x7dffb5, 7, 0.32); halo.position.set(0, 1.7, -0.6); orchid.add(halo);
    var beam = plane(5, 7, new THREE.MeshBasicMaterial({ map: coneT, color: 0xcfffe2, transparent: true, opacity: 0.12, blending: THREE.AdditiveBlending, depthWrite: false, fog: false })); beam.position.set(0, 3.2, -0.3); orchid.add(beam);
    orchid.position.set(0, 0, ORCH_Z); orchid.userData.flower = flower; g.add(orchid); place(orchid, 1.3, 1.15);
    /* fotos 29–31 */
    [[3.6, -421, -0.5], [-6.3, -434, 1.0], [3.3, -444, -0.45]].forEach(function(e, n){
      var eg = new THREE.Group();
      var f = addPhoto(eg, pad2(n + 29), 2.5, { border: 0.09, maxW: 3.2 }); f.position.y = 0.45; f.rotation.x = -0.05;
      [-0.5, 0.5].forEach(function(px){ var l = box(0.06, 2.6, 0.06, basic(0x0c0f0e)); l.position.set(px, -0.3, -0.12); l.rotation.x = 0.12; eg.add(l); });
      eg.position.set(0, 0, e[1]); eg.rotation.y = e[2]; g.add(eg); place(eg, e[0], 1);
    });
    /* las dos orillas en un solo lugar: una guirnalda tricolor y un poste de sodio */
    var bl = [], cols = [0xfcd116, 0x3f7dff, 0xff3b3b, 0xffb347];
    for (var j = 0; j <= 16; j++){ var x = -8 + j, y = 5.2 - 1.2 * (1 - Math.pow(x / 8, 2)); pushPt(bl, x, y, -426, cols[j % 4], 1); pushPt(bl, x * 0.9, y + 0.3, -440, cols[(j + 2) % 4], 0.9); }
    g.add(pts(bl, 0.6));
    lamp(g, -5.2, -418, 0xff9d3c, 5);
    addMist(g, tier ? 22 : 10, 0x8fb3a0, 0.1, -12, 12, -1.0, 2.4, -450, -412, 8, 15);
  })();

  /* ============ 10. EL CORTE: la calle es una línea de tiempo ============ */
  var CUTS = [-462, -473, -484, -495], LANES = [-1, 1, -1, 1], LANE_W = 1.7;
  var playhead = new THREE.Group(), cutG = new THREE.Group();
  (function(){
    var g = grp(9);
    var gridT = cv(64, 64, function(x){ x.fillStyle = '#030303'; x.fillRect(0, 0, 64, 64); x.strokeStyle = '#121212'; x.lineWidth = 2; x.strokeRect(0, 0, 64, 64); }, [24, 36]);
    g.add(floor(36, 56, new THREE.MeshBasicMaterial({ map: gridT }), 0, Y0, -474));
    /* clips en tres pistas */
    var defs = [], laneCol = [[0.76, 0.3, 0.2], [0.55, 0.42, 0.2], [0.42, 0.34, 0.17]];
    [-1, 0, 1].forEach(function(ln, li){
      var z = -451.5;
      while (z > -497){ var len = rr(2.6, 7.5); if (z - len < -497.5) len = z + 497.5; defs.push({ ln: ln, z: z - len / 2, len: len, c: new THREE.Color().setHSL(laneCol[li][0] + rr(-0.03, 0.03), laneCol[li][1], laneCol[li][2] * rr(0.8, 1.25)) }); z -= len + 0.14; }
    });
    var clips = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), new THREE.MeshBasicMaterial(), defs.length), dm = new THREE.Object3D();
    defs.forEach(function(d, n){ clips.setColorAt(n, d.c); });
    /* forma de onda sobre la pista de audio */
    var NW = 230, wave = new THREE.InstancedMesh(new THREE.BoxGeometry(1, 1, 1), basic(0x0c8a40), NW * 2), hs = [];
    for (var i = 0; i < NW * 2; i++){ var b = Math.pow(Math.abs(Math.sin(i * 0.41)), 6); hs.push(0.04 + rr(0, 0.16) + b * rr(0.2, 0.62)); }
    respread.push(function(){
      var lw = LANE_W * lerp(0.5, 1, kR);
      defs.forEach(function(d, n){ dm.position.set(d.ln * lw, Y0 + 0.06, d.z); dm.scale.set(lw * 0.9, 0.12, d.len); dm.rotation.set(0, 0, 0); dm.updateMatrix(); clips.setMatrixAt(n, dm.matrix); });
      clips.instanceMatrix.needsUpdate = true;
      /* el audio va en estéreo: una onda a cada lado, fuera de los carriles por donde pasa la cámara */
      for (var n = 0; n < NW * 2; n++){ dm.position.set((n < NW ? 2 : -2) * lw, Y0 + hs[n] / 2, -452 - (n % NW) * 0.2); dm.scale.set(lw * 0.8, hs[n], 0.09); dm.updateMatrix(); wave.setMatrixAt(n, dm.matrix); }
      wave.instanceMatrix.needsUpdate = true;
    });
    clips.frustumCulled = false; wave.frustumCulled = false; g.add(clips); g.add(wave);
    /* fotos 32–35 en la pista central, cada una con su oficio */
    ['DIRIJO', 'EDITO', 'FOTOGRAF\u00cdO', 'MEZCLO'].forEach(function(w, n){
      var pg2 = new THREE.Group();
      var f = addPhoto(pg2, pad2(n + 32), 1.75, { border: 0.05, borderColor: 0x00ff66, maxW: 2.3 }); f.position.y = Y0 + 0.2 + f.userData.h / 2;
      var t = textPlane([w], 0.5, { weight: 700, size: 130, color: '#ece8df' }); t.position.y = Y0 + 0.2 + f.userData.h + 0.45; pg2.add(t);
      pg2.position.set(0, 0, CUTS[n] + 3.4); pg2.rotation.y = LANES[n] * 0.4; g.add(pg2);
    });
    /* el cabezal: una pared de luz verde que va adelante */
    var phT = cv(8, 128, function(x){ var gr = x.createLinearGradient(0, 128, 0, 0); gr.addColorStop(0, 'rgba(0,255,102,0.9)'); gr.addColorStop(0.05, 'rgba(0,255,102,0.3)'); gr.addColorStop(1, 'rgba(0,255,102,0)'); x.fillStyle = gr; x.fillRect(0, 0, 8, 128); });
    var wall = plane(14, 3.4, new THREE.MeshBasicMaterial({ map: phT, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false })); wall.position.y = Y0 + 1.7; playhead.add(wall);
    var bar = box(14, 0.04, 0.04, basic(0x00ff66, { fog: false })); bar.position.y = Y0 + 0.14; playhead.add(bar);
    playhead.visible = false; g.add(playhead);
  })();

  /* ============ 11. EL VISOR: un marco de luz y la última foto ============ */
  var lastPhoto = null, lastFrame = new THREE.Group();
  (function(){
    var g = grp(10);
    lastPhoto = addPhoto(g, '36', 6);
    var u = lastPhoto.userData, wm = basic(0xece8df, { fog: false }), t = 0.035, o = 0.3;
    [[0, u.h / 2 + o, u.w + o * 2, t], [0, -u.h / 2 - o, u.w + o * 2, t], [-u.w / 2 - o, 0, t, u.h + o * 2], [u.w / 2 + o, 0, t, u.h + o * 2]].forEach(function(e){
      var m = plane(e[2], e[3], wm); m.position.set(e[0], e[1], 0.01); lastFrame.add(m);
    });
    lastPhoto.add(lastFrame);
    var dust = []; for (var i = 0; i < 120; i++){ pushPt(dust, rr(-6, 6), rr(-3.5, 3.5), rr(-528, -498), 0xece8df, rr(0.2, 0.6)); }
    g.add(pts(dust, 0.07));
  })();

  /* ============ TELÓN DE FONDO: sigue a la cámara, como algo que está en el infinito ============ */
  var back = new THREE.Group(); scene.add(back);
  var mtnM, starsM, skyM, hzM, moon, monse;
  (function(){
    function ridge(x, base, amp, col, s0){
      x.fillStyle = col; x.beginPath(); x.moveTo(0, 256);
      for (var px = 0; px <= 1024; px += 8){ var y = base - (Math.sin(px * 0.006 + s0) * 0.5 + Math.sin(px * 0.017 + s0 * 2.3) * 0.3 + Math.sin(px * 0.041 + s0 * 5.1) * 0.2 + 1) * amp * 0.5; x.lineTo(px, y); }
      x.lineTo(1024, 256); x.closePath(); x.fill();
    }
    var mtnT = cv(1024, 256, function(x){
      ridge(x, 150, 120, '#1a2730', 1.1); ridge(x, 170, 90, '#111b21', 4.2); ridge(x, 196, 70, '#0a1014', 7.7);
      var gr = x.createLinearGradient(0, 150, 0, 256); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(1, 'rgba(0,0,0,1)');
      x.globalCompositeOperation = 'destination-out'; x.fillStyle = gr; x.fillRect(0, 150, 1024, 106);
    });
    mtnM = new THREE.MeshBasicMaterial({ map: mtnT, transparent: true, opacity: 0, depthWrite: false, fog: false });
    var mt = plane(330, 48, mtnM); mt.position.set(0, 9, -100); back.add(mt);
    var hzT = cv(8, 128, function(x){ var gr = x.createLinearGradient(0, 128, 0, 0); gr.addColorStop(0, 'rgba(255,255,255,0)'); gr.addColorStop(0.3, 'rgba(255,255,255,0.9)'); gr.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = gr; x.fillRect(0, 0, 8, 128); });
    hzM = new THREE.MeshBasicMaterial({ map: hzT, transparent: true, opacity: 0, depthWrite: false, fog: false, blending: THREE.AdditiveBlending });
    var hz = plane(360, 46, hzM); hz.position.set(0, 3, -104); back.add(hz);
    var skyT = cv(1024, 128, function(x){
      var px = 0;
      while (px < 1024){
        var w = rr(18, 46), h = rr(24, 96); x.fillStyle = '#070b0a'; x.fillRect(px, 128 - h, w, h);
        for (var n = 0; n < h * w / 190; n++){ x.fillStyle = rnd() < 0.7 ? 'rgba(255,208,140,0.7)' : 'rgba(190,255,220,0.6)'; x.fillRect(px + 3 + Math.floor(rnd() * (w - 6) / 4) * 4, 128 - h + 4 + Math.floor(rnd() * (h - 6) / 5) * 5, 2, 2.5); }
        px += w + rr(0, 5);
      }
    });
    skyM = new THREE.MeshBasicMaterial({ map: skyT, transparent: true, opacity: 0, depthWrite: false, fog: false });
    var sk = plane(250, 30, skyM); sk.position.set(0, 4.5, -88); back.add(sk);
    var st = []; for (var i = 0; i < 280; i++){ pushPt(st, rr(-150, 150), rr(4, 90), rr(-125, -60), rnd() < 0.8 ? 0xffffff : 0xcfe0ff, rr(0.35, 1)); }
    var sp = pts(st, 1.25); starsM = sp.material; starsM.opacity = 0; back.add(sp);
    moon = glow(0xdfe7ff, 18, 0); moon.position.set(38, 30, -105); back.add(moon);
    monse = glow(0xffffff, 2.2, 0); monse.position.set(-22, 21.5, -99); back.add(monse);   // la iglesia iluminada en el cerro
  })();
