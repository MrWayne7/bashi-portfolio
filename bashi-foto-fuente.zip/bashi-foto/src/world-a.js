/* ============================================================
   THREE.JS — "Ida y vuelta": el viaje ocurre dentro de la cámara
   ============================================================ */
var SKY = null;     // lo que la interfaz puede pedirle al mundo 3D
function skyOff(){ document.documentElement.classList.add('gl-off'); }
function initWorld(){
  if (!window.THREE){ skyOff(); return; }
  var THREE = window.THREE;
  var canvas = $('#gl'), renderer;
  try {
    renderer = new THREE.WebGLRenderer({ canvas: canvas, antialias: true, powerPreference: 'high-performance' });
  } catch (e) { skyOff(); return; }
  var gl2 = renderer.capabilities.isWebGL2;

  /* si el navegador pierde el contexto gráfico: se muestra el fondo fijo y al volver se reconstruye */
  var lost = false, shown = false;
  canvas.addEventListener('webglcontextlost', function(){ lost = true; document.documentElement.classList.add('gl-lost'); });
  canvas.addEventListener('webglcontextrestored', function(){ lost = false; document.documentElement.classList.remove('gl-lost'); post.forget(); resize(); });

  var tier = Q.tier;
  var PI = Math.PI, TAU = PI * 2;
  var seed = 11;
  function rnd(){ seed = (seed + 0x6D2B79F5) | 0; var t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }
  function rr(a, b){ return a + (b - a) * rnd(); }

  /* ---- ambiente de cada escena: [fondo, niebla cerca, niebla lejos, resplandor, grano] ---- */
  var ENV = [
    [0x000000, 5, 30, 0.75, 0.05],    // el lente
    [0x0b0603, 5, 34, 0.55, 0.11],    // el rollo
    [0x0d1418, 1.5, 24, 0.7, 0.06],   // la niebla
    [0x0c0906, 5, 44, 0.6, 0.05],     // la plaza
    [0x070a14, 8, 62, 0.6, 0.045],    // el salto
    [0x06080d, 6, 54, 0.6, 0.06],     // nueva york
    [0x0d0616, 6, 50, 0.8, 0.05],     // miami
    [0x150306, 3, 30, 0.7, 0.07],     // atlanta
    [0x0b1210, 3, 36, 0.65, 0.055],   // la mezcla
    [0x040404, 5, 40, 0.6, 0.05],     // el corte
    [0x000000, 8, 60, 0.35, 0.04]     // el visor
  ];
  /* telón de fondo de cada escena: [montañas, estrellas, perfil de ciudad, color del horizonte, fuerza del horizonte] */
  var BK = [
    [0, 0, 0, 0x000000, 0], [0, 0, 0, 0xffb347, 0], [0.75, 0, 0, 0x4a6470, 0.22], [0.8, 0.5, 0, 0xff9d3c, 0.2],
    [0, 1, 0, 0x24345e, 0.35], [0, 0.5, 0, 0x3b5a8a, 0.3], [0, 0.25, 0, 0xff3f8e, 0.62], [0, 0, 0, 0x000000, 0],
    [1, 0.4, 1, 0x3fae7a, 0.25], [0.3, 0, 0.5, 0x00ff66, 0.06], [0, 0, 0, 0x000000, 0]
  ];
  ENV.forEach(function(e){ e[0] = new THREE.Color(e[0]); });
  BK.forEach(function(b){ b[3] = new THREE.Color(b[3]); });

  var scene = new THREE.Scene();
  var bg = new THREE.Color(0x000000);
  scene.background = bg;
  scene.fog = new THREE.Fog(0x000000, 5, 30);
  var U = { time: { value: 0 }, fogColor: { value: scene.fog.color }, fogNear: { value: 5 }, fogFar: { value: 30 } };
  var camera = new THREE.PerspectiveCamera(52, 1, 0.1, 170);

  var tl = new THREE.TextureLoader();
  function noMip(t){ t.minFilter = THREE.LinearFilter; t.generateMipmaps = false; return t; }
  function canvasTex(c){ return noMip(new THREE.CanvasTexture(c)); }
  /* textura dibujada por código; rep = [x, y] la repite (tamaños potencia de 2) */
  function cv(w, h, fn, rep){
    var c = document.createElement('canvas'); c.width = w; c.height = h;
    fn(c.getContext('2d'), w, h);
    var t = canvasTex(c);
    if (rep){ t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(rep[0], rep[1]); }
    return t;
  }
  var grayTex = noMip(new THREE.DataTexture(new Uint8Array([34, 32, 30, 255]), 1, 1, THREE.RGBAFormat)); grayTex.needsUpdate = true;

  /* ---- responsive del mundo 3D ---- */
  var aspect = 1, kR = 1, spread = 1, sizeK = 1, AMP = 2.4, baseFov = 52;
  var placed = [], respread = [];
  /* place(objeto, x base, escala, enElAire): lo recoloca según la proporción de pantalla.
     Lo que está parado en el piso (por defecto) se encoge sin despegarse de él. */
  function place(o, bx, s, air){ o.userData.bx = bx; o.userData.bs = s || 0; o.userData.gnd = !!s && !air; placed.push(o); return o; }
  function applySpread(){
    placed.forEach(function(o){
      o.position.x = o.userData.bx * spread;
      if (o.userData.bs) o.scale.setScalar(o.userData.bs * sizeK);
      if (o.userData.gnd) o.position.y = -1.2 * (1 - o.scale.y);
    });
    respread.forEach(function(f){ f(); });
  }

  /* ---- sprites y piezas básicas ---- */
  function radialTex(stops){
    return cv(128, 128, function(x){
      var g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
      stops.forEach(function(s){ g.addColorStop(s[0], s[1]); });
      x.fillStyle = g; x.fillRect(0, 0, 128, 128);
    });
  }
  var glowT = radialTex([[0, 'rgba(255,255,255,1)'], [0.18, 'rgba(255,255,255,0.85)'], [0.5, 'rgba(255,255,255,0.22)'], [1, 'rgba(255,255,255,0)']]);
  var softT = radialTex([[0, 'rgba(255,255,255,0.9)'], [0.45, 'rgba(255,255,255,0.4)'], [1, 'rgba(255,255,255,0)']]);
  var coneT = cv(128, 128, function(x){
    var g = x.createRadialGradient(64, 0, 0, 64, 0, 128); g.addColorStop(0, 'rgba(255,255,255,0.9)'); g.addColorStop(1, 'rgba(255,255,255,0)');
    x.fillStyle = g; x.beginPath(); x.moveTo(64, 0); x.lineTo(128, 128); x.lineTo(0, 128); x.closePath(); x.fill();
  });
  function glow(color, size, op){
    var s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowT, color: color, transparent: true, opacity: op === undefined ? 1 : op, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
    s.scale.setScalar(size); return s;
  }
  function pts(arr, size){          // arr: x,y,z,r,g,b por punto
    var n = arr.length / 6, pos = new Float32Array(n * 3), col = new Float32Array(n * 3);
    for (var i = 0; i < n; i++){ pos[i*3] = arr[i*6]; pos[i*3+1] = arr[i*6+1]; pos[i*3+2] = arr[i*6+2]; col[i*3] = arr[i*6+3]; col[i*3+1] = arr[i*6+4]; col[i*3+2] = arr[i*6+5]; }
    var g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(pos, 3)); g.setAttribute('color', new THREE.BufferAttribute(col, 3));
    return new THREE.Points(g, new THREE.PointsMaterial({ size: size, map: glowT, vertexColors: true, transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
  }
  function pushPt(arr, x, y, z, hex, k){ var c = new THREE.Color(hex); k = k === undefined ? 1 : k; arr.push(x, y, z, c.r * k, c.g * k, c.b * k); }
  function basic(color, o){ o = o || {}; o.color = color; return new THREE.MeshBasicMaterial(o); }
  function box(w, h, d, mat){ return new THREE.Mesh(new THREE.BoxGeometry(w, h, d), mat); }
  function plane(w, h, mat){ return new THREE.Mesh(new THREE.PlaneGeometry(w, h), mat); }
  function floor(w, d, mat, x, y, z){ var m = plane(w, d, mat); m.rotation.x = -PI / 2; m.position.set(x, y, z); return m; }
  function lineSeg(arr, color, op){
    var g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(new Float32Array(arr), 3));
    return new THREE.LineSegments(g, new THREE.LineBasicMaterial({ color: color, transparent: op !== undefined, opacity: op === undefined ? 1 : op }));
  }

  /* ---- texto en canvas ---- */
  var F_GOT = '"Pirata One", "Old English Text MT", serif', F_CON = '"Barlow Condensed", "Arial Narrow", sans-serif', F_OSD = '"VT323", monospace';
  function textTex(lines, o){
    o = o || {};
    var fs = o.size || 120, font = (o.weight || 700) + ' ' + fs + 'px ' + (o.family || F_CON);
    var mc = document.createElement('canvas').getContext('2d'); mc.font = font;
    var w = 0; lines.forEach(function(l){ w = Math.max(w, mc.measureText(l).width); });
    var padk = o.glow ? 0.9 : 0.3;
    w = Math.ceil(w + fs * padk * 2); var lh = fs * 1.08, h = Math.ceil(lh * lines.length + fs * padk * 2);
    var k = Math.min(1, 2048 / w);
    var c = document.createElement('canvas'); c.width = Math.ceil(w * k); c.height = Math.ceil(h * k);
    var x = c.getContext('2d'); x.scale(k, k); x.font = font; x.textBaseline = 'middle'; x.textAlign = 'center';
    lines.forEach(function(l, i){
      var ty = fs * padk + lh * (i + 0.5);
      if (o.glow){ x.shadowColor = o.color || '#fff'; x.shadowBlur = fs * 0.45; x.fillStyle = o.color || '#fff'; x.fillText(l, w / 2, ty); x.fillText(l, w / 2, ty); x.shadowBlur = fs * 0.12; x.fillStyle = '#fff'; x.fillText(l, w / 2, ty); }
      else { x.fillStyle = o.color || '#fff'; x.fillText(l, w / 2, ty); }
    });
    return { tex: canvasTex(c), a: w / h };
  }
  function textPlane(lines, height, o){
    o = o || {};
    var t = textTex(lines, o);
    var m = plane(height * t.a, height, new THREE.MeshBasicMaterial({ map: t.tex, transparent: true, depthWrite: false, fog: o.fog !== false && !o.glow,
      blending: o.glow ? THREE.AdditiveBlending : THREE.NormalBlending, side: THREE.DoubleSide }));
    m.userData.w = height * t.a;
    return m;
  }

  /* ---- las fotos: un solo material; en el rollo llegan como negativo con grano y se revelan ---- */
  var PH_VS = 'varying vec2 vUv; varying float vF; void main(){ vUv=uv; vec4 mv=modelViewMatrix*vec4(position,1.0); vF=-mv.z; gl_Position=projectionMatrix*mv; }';
  var PH_FS = [
    'uniform sampler2D map; uniform float uDev,uTime,fogNear,fogFar; uniform vec3 fogColor,uTint; varying vec2 vUv; varying float vF;',
    'float h(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }',
    'void main(){',
    '  vec3 c=texture2D(map,vUv).rgb;',
    '  if(uDev>0.001){',
    '    float g=h(floor(vUv*110.0)+floor(uTime*14.0));',
    '    float l=dot(c,vec3(0.3,0.59,0.11));',
    '    vec3 neg=vec3(0.86,0.44,0.16)*(1.05-l);',
    '    c=mix(c, mix(neg, vec3(g)*0.75, 0.42), smoothstep(0.0,1.0,uDev));',
    '  }',
    '  c*=uTint;',
    '  gl_FragColor=vec4(mix(c,fogColor,smoothstep(fogNear,fogFar,vF)),1.0);',
    '}'].join('\n');
  var photos = [], pickables = [];
  function addPhoto(parent, key, h, o){
    o = o || {};
    var a = TEX[key] ? TEX[key].a : 0.8, w = h * a;
    if (o.maxW && w > o.maxW){ w = o.maxW; h = w / a; }
    var g = new THREE.Group();
    var mat = new THREE.ShaderMaterial({ uniforms: { map: { value: grayTex }, uDev: { value: 0 }, uTint: { value: new THREE.Color(1, 1, 1) }, uTime: U.time,
      fogColor: U.fogColor, fogNear: U.fogNear, fogFar: U.fogFar }, vertexShader: PH_VS, fragmentShader: PH_FS });
    var ph = plane(w, h, mat); g.add(ph);
    if (o.border){ var b = plane(w + o.border * 2, h + o.border * 2, basic(o.borderColor === undefined ? 0xe9e4d8 : o.borderColor)); b.position.z = -0.015; g.add(b); }
    var m = META[key] || {};
    g.userData = { key: key, st: 0, tex: null, mat: mat, mesh: ph, w: w, h: h, wp: new THREE.Vector3(), dev: !!o.dev,
                   info: { n: key, title: m.t || escenaDe(key), desc: m.d || '' } };
    ph.userData.frame = g;
    parent.add(g); photos.push(g); pickables.push(ph);
    return g;
  }
  /* las fotos se cargan al acercarte a su escena y se liberan al dejarla atrás (cuida la memoria del teléfono) */
  function ensureTex(g){
    var u = g.userData; if (u.st || !TEX[u.key]) return;
    u.st = 1;
    tl.load(TEX[u.key].u, function(t){
      noMip(t);
      if (u.st !== 1){ t.dispose(); return; }
      u.tex = t; u.mat.uniforms.map.value = t; u.st = 2;
    }, undefined, function(){ u.st = 0; });
  }
  function dropTex(g){
    var u = g.userData;
    if (u.st === 2){ u.mat.uniforms.map.value = grayTex; u.tex.dispose(); u.tex = null; }
    u.st = 0;
  }

  var journey = new THREE.Group(); scene.add(journey);
  var G = [];
  function grp(i){ var g = new THREE.Group(); journey.add(g); G[i] = g; return g; }
  var Y0 = -1.2;                    // altura del piso en las escenas de calle

  /* niebla baja y vapor: nubes planas que derivan */
  var mist = [];
  function addMist(parent, n, color, op, x0, x1, y0, y1, z0, z1, s0, s1){
    for (var i = 0; i < n; i++){
      var s = new THREE.Sprite(new THREE.SpriteMaterial({ map: softT, color: color, transparent: true, opacity: op * rr(0.6, 1), depthWrite: false, fog: false }));
      s.position.set(rr(x0, x1), rr(y0, y1), rr(z0, z1)); s.scale.setScalar(rr(s0, s1));
      s.userData = { drift: rr(-0.35, 0.35), x0: x0, x1: x1 };
      parent.add(s); mist.push(s);
    }
  }
  /* poste de luz: palo, brazo, bombillo y cono de luz */
  function lamp(parent, bx, z, color, hgt){
    var g = new THREE.Group(), side = bx > 0 ? -1 : 1; hgt = hgt || 4.4;
    var pole = box(0.12, hgt, 0.12, basic(0x0b0c0e)); pole.position.y = Y0 + hgt / 2; g.add(pole);
    var arm = box(1.0, 0.08, 0.08, basic(0x0b0c0e)); arm.position.set(side * 0.5, Y0 + hgt, 0); g.add(arm);
    var a = glow(color, 2.3, 0.75); a.position.set(side * 1.0, Y0 + hgt - 0.1, 0); g.add(a);
    var b = glow(0xffffff, 0.5, 1); b.position.copy(a.position); g.add(b);
    var c = plane(4.6, hgt, new THREE.MeshBasicMaterial({ map: coneT, color: color, transparent: true, opacity: 0.09, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
    c.position.set(side * 1.0, Y0 + hgt / 2 - 0.1, 0); g.add(c);
    g.position.z = z; parent.add(g); place(g, bx, 0);
    return g;
  }

  /* ============ 1. EL LENTE: se entra por el objetivo y el diafragma se abre ============ */
  var iris = [], IRIS_Z = -24;
  (function(){
    var g = grp(0);
    var barT = cv(16, 512, function(x, w, h){
      x.fillStyle = '#0a0a0b'; x.fillRect(0, 0, w, h);
      for (var y = 0; y < h; y += 32){ x.fillStyle = '#1d1e22'; x.fillRect(0, y, w, 3); x.fillStyle = '#050506'; x.fillRect(0, y + 3, w, 2); }
    }, [1, 1]);
    var barrel = new THREE.Mesh(new THREE.CylinderGeometry(4.3, 4.3, 37, 40, 1, true), new THREE.MeshBasicMaterial({ map: barT, side: THREE.BackSide }));
    barrel.rotation.x = PI / 2; barrel.position.z = -14.5; g.add(barrel);
    /* aro frontal con el grabado */
    var ringT = cv(1024, 1024, function(x){
      x.translate(512, 512);
      var gr = x.createRadialGradient(0, 0, 330, 0, 0, 512); gr.addColorStop(0, '#0d0d0f'); gr.addColorStop(0.5, '#1c1c20'); gr.addColorStop(1, '#09090a');
      x.fillStyle = gr; x.beginPath(); x.arc(0, 0, 512, 0, TAU); x.arc(0, 0, 330, 0, TAU, true); x.fill();
      x.strokeStyle = '#3a3b40'; x.lineWidth = 2; [338, 380, 470, 506].forEach(function(r){ x.beginPath(); x.arc(0, 0, r, 0, TAU); x.stroke(); });
      var txt = 'BASHI   1:1.4 / 35 mm   \u2022   HECHO EN FUSAGASUG\u00c1   \u2022   COLOMBIA   \u2022   \u00d8 52   \u2022   ';
      x.font = '600 40px ' + F_CON; x.fillStyle = '#d8d3c8'; x.textAlign = 'center'; x.textBaseline = 'middle';
      var tot = 0, i, ws = []; for (i = 0; i < txt.length; i++){ ws.push(x.measureText(txt[i]).width + 3); tot += ws[i]; }
      var ang = -PI / 2 - (tot / 425) / 2;
      for (i = 0; i < txt.length; i++){ ang += ws[i] / 2 / 425; x.save(); x.rotate(ang); x.translate(0, -425); x.fillText(txt[i], 0, 0); x.restore(); ang += ws[i] / 2 / 425; }
    });
    var front = new THREE.Mesh(new THREE.RingGeometry(3.45, 5.35, 72), new THREE.MeshBasicMaterial({ map: ringT, transparent: true, fog: false }));
    front.position.z = 4; g.add(front);
    var hood = new THREE.Mesh(new THREE.RingGeometry(5.3, 30, 48), basic(0x020202, { fog: false })); hood.position.z = 3.98; g.add(hood);
    /* elementos de vidrio */
    var glassT = cv(256, 256, function(x){
      var gr = x.createRadialGradient(128, 128, 60, 128, 128, 128); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.8, 'rgba(80,60,160,0.12)'); gr.addColorStop(1, 'rgba(120,255,190,0.3)');
      x.fillStyle = gr; x.beginPath(); x.arc(128, 128, 128, 0, TAU); x.fill();
      x.lineCap = 'round';
      x.strokeStyle = 'rgba(255,255,255,0.5)'; x.lineWidth = 7; x.beginPath(); x.arc(128, 128, 104, PI * 1.12, PI * 1.42); x.stroke();
      x.strokeStyle = 'rgba(255,120,220,0.3)'; x.lineWidth = 12; x.beginPath(); x.arc(128, 128, 84, PI * 0.1, PI * 0.36); x.stroke();
      x.strokeStyle = 'rgba(120,255,200,0.26)'; x.lineWidth = 5; x.beginPath(); x.arc(128, 128, 60, PI * 1.55, PI * 1.9); x.stroke();
    });
    [[0.5, 3.3], [-6, 3.05], [-12, 2.85], [-18, 2.7]].forEach(function(e, n){
      var t1 = new THREE.Mesh(new THREE.TorusGeometry(e[1] + 0.55, 0.62, 10, 56), basic(0x101012)); t1.position.z = e[0]; g.add(t1);
      var t2 = new THREE.Mesh(new THREE.TorusGeometry(e[1] - 0.02, 0.035, 6, 56), basic(0x7f8794)); t2.position.z = e[0] + 0.3; g.add(t2);
      var d = new THREE.Mesh(new THREE.CircleGeometry(e[1], 48), new THREE.MeshBasicMaterial({ map: glassT, transparent: true, opacity: 0.75, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
      d.position.z = e[0]; d.rotation.z = n * 1.3; g.add(d);
    });
    /* diafragma: 8 hojas que forman un octágono */
    var bladeT = cv(64, 64, function(x){ var gr = x.createLinearGradient(0, 64, 0, 0); gr.addColorStop(0, '#3a3c42'); gr.addColorStop(0.06, '#1b1c20'); gr.addColorStop(1, '#070708'); x.fillStyle = gr; x.fillRect(0, 0, 64, 64); });
    for (var i = 0; i < 8; i++){
      var b = plane(16, 8, new THREE.MeshBasicMaterial({ map: bladeT, color: new THREE.Color().setScalar(0.75 + (i % 3) * 0.14) }));
      b.userData.a = i / 8 * TAU; b.rotation.z = b.userData.a - PI / 2; b.position.z = IRIS_Z - i * 0.012;
      g.add(b); iris.push(b);
    }
    /* la luz al otro lado */
    var disc = new THREE.Mesh(new THREE.CircleGeometry(7, 32), basic(0xffffff, { fog: false })); disc.position.z = IRIS_Z - 5.5; g.add(disc);
    var lg = glow(0xfff2dc, 30, 1); lg.position.z = IRIS_Z - 5; g.add(lg);
    /* polvo en el haz */
    var dust = []; for (i = 0; i < 150; i++){ var a = rnd() * TAU, r = rr(0.3, 3.2); pushPt(dust, Math.cos(a) * r, Math.sin(a) * r, rr(-23, 6), 0xfff0d8, rr(0.25, 0.8)); }
    g.add(pts(dust, 0.09));
  })();

  /* ============ 2. EL ROLLO: la cinta en hélice y las primeras fotos ============ */
  (function(){
    var g = grp(1);
    var filmT = cv(256, 256, function(x){
      x.fillStyle = '#0e0805'; x.fillRect(0, 0, 256, 256);
      x.fillStyle = '#1b110a'; x.fillRect(10, 58, 236, 140); x.strokeStyle = '#3d2817'; x.lineWidth = 2; x.strokeRect(10, 58, 236, 140);
      x.fillStyle = 'rgba(255,186,104,0.62)';
      for (var i = 0; i < 4; i++){ [16, 214].forEach(function(y){ var px = 18 + i * 64; x.beginPath(); x.moveTo(px + 5, y); x.arcTo(px + 28, y, px + 28, y + 26, 5); x.arcTo(px + 28, y + 26, px, y + 26, 5); x.arcTo(px, y + 26, px, y, 5); x.arcTo(px, y, px + 28, y, 5); x.fill(); }); }
      x.fillStyle = 'rgba(255,186,104,0.5)'; x.font = '22px ' + F_OSD; x.fillText('BASHI 400', 14, 54); x.fillText('36', 214, 212);
    }, [1, 1]);
    var R = 3.7, P = 13, turns = 4.3, segs = 280, hw = 1.05, A0 = 0.4;
    var pos = [], uv = [], idx = [];
    for (var i = 0; i <= segs; i++){
      var a = A0 + i / segs * turns * TAU, z = -35 - (a - A0) * P / TAU, c = Math.cos(a), s = Math.sin(a);
      pos.push(R * c, R * s, z + hw, R * c, R * s, z - hw);
      uv.push(a * R / 2.5, 0, a * R / 2.5, 1);
      if (i < segs){ var k = i * 2; idx.push(k, k + 1, k + 2, k + 1, k + 3, k + 2); }
    }
    var geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(new Float32Array(pos), 3)); geo.setAttribute('uv', new THREE.BufferAttribute(new Float32Array(uv), 2)); geo.setIndex(idx);
    g.add(new THREE.Mesh(geo, new THREE.MeshBasicMaterial({ map: filmT, side: THREE.DoubleSide })));
    /* fotos 01–06 en espiral, inclinadas hacia quien llega */
    for (i = 0; i < 6; i++){
      var an = 0.7 + i * 1.3, pz = -44 - i * 8;
      var f = addPhoto(g, pad2(i + 1), 2.3, { dev: true, border: 0.06, borderColor: 0x140c07, maxW: 3.0 });
      f.position.set(Math.cos(an) * 2.15, Math.sin(an) * 2.15, pz);
      f.lookAt(Math.cos(an) * 0.4, Math.sin(an) * 0.4, pz + 8);
      f.rotateZ(rollAt(pz + 6.5));
      f.userData.rollo = true;
    }
    var end = glow(0xffb347, 7, 0.55); end.position.set(0, 0.6, -93); g.add(end);
    var dust = []; for (i = 0; i < 160; i++){ var b = rnd() * TAU, r = rr(0.2, 3.2); pushPt(dust, Math.cos(b) * r, Math.sin(b) * r, rr(-90, -32), 0xffc98a, rr(0.2, 0.7)); }
    g.add(pts(dust, 0.08));
  })();

  /* ============ 3. LA NIEBLA: carretera de montaña, de noche ============ */
  var roadT = cv(128, 256, function(x){
    x.fillStyle = '#0d0f11'; x.fillRect(0, 0, 128, 256);
    for (var i = 0; i < 500; i++){ x.fillStyle = 'rgba(255,255,255,' + (rnd() * 0.035).toFixed(3) + ')'; x.fillRect(rnd() * 128, rnd() * 256, 1.5, 1.5); }
    x.fillStyle = '#7d6617'; x.fillRect(62, 20, 4, 110);
    x.fillStyle = 'rgba(190,196,202,0.5)'; x.fillRect(6, 0, 3, 256); x.fillRect(119, 0, 3, 256);
  }, [1, 6]);
  (function(){
    var g = grp(2);
    g.add(floor(90, 44, basic(0x06090a), 0, Y0 - 0.02, -111));
    var road = floor(7, 44, new THREE.MeshBasicMaterial({ map: roadT }), 0, Y0, -111); g.add(road);
    respread.push(function(){ road.scale.x = lerp(0.6, 1, kR); });
    /* el primer bombillo: es la luz que se veía al fondo del rollo */
    var wire = lineSeg([0, 7, -96.5, 0, 2.5, -96.5], 0x1a1a1a); g.add(wire);
    var b1 = glow(0xffb347, 2.6, 0.8); b1.position.set(0, 2.35, -96.5); g.add(b1);
    var b2 = glow(0xffffff, 0.45, 1); b2.position.copy(b1.position); g.add(b2);
    lamp(g, 4.1, -106, 0xffa640); lamp(g, -4.1, -118, 0xffa640); lamp(g, 4.1, -128, 0xffa640);
    /* cerca de alambre de púas a los lados */
    var postG = new THREE.BoxGeometry(0.09, 1.25, 0.09), postM = basic(0x15120e);
    [-1, 1].forEach(function(sd){
      var fg = new THREE.Group(), w = [];
      for (var z = -94; z > -131; z -= 2.6){ var p = new THREE.Mesh(postG, postM); p.position.set(0, Y0 + 0.62, z); p.rotation.z = rr(-0.08, 0.08); fg.add(p); }
      [0.5, 0.85, 1.15].forEach(function(h){ w.push(0, Y0 + h, -94, 0, Y0 + h, -131); });
      fg.add(lineSeg(w, 0x2a2622)); g.add(fg); place(fg, sd * 4.9, 0);
    });
    /* señal de carretera */
    var signT = cv(512, 192, function(x){
      x.fillStyle = '#0a5a33'; x.fillRect(0, 0, 512, 192); x.strokeStyle = '#e8ece8'; x.lineWidth = 8; x.strokeRect(12, 12, 488, 168);
      x.fillStyle = '#eef2ee'; x.textAlign = 'center'; x.textBaseline = 'middle'; x.font = '700 82px ' + F_CON; x.fillText('FUSAGASUG\u00c1', 256, 82);
      x.font = '600 38px ' + F_CON; x.fillText('CIUDAD JARD\u00cdN  \u2191', 256, 146);
    });
    var sg = new THREE.Group();
    var sb = plane(3.5, 1.32, new THREE.MeshBasicMaterial({ map: signT })); sb.position.y = 1.5; sg.add(sb);
    [-1.3, 1.3].forEach(function(px){ var p = box(0.09, 3.4, 0.09, basic(0x101214)); p.position.set(px, 0.3 - 0.6, -0.06); sg.add(p); });
    sg.position.set(0, 0, -114); sg.rotation.y = -0.3; g.add(sg); place(sg, 3.6, 1);
    addMist(g, tier ? 26 : 12, 0x93a7b0, 0.11, -11, 11, -1.0, 2.6, -131, -93, 8, 16);
  })();

  /* ============ 4. LA PLAZA: guirnaldas, banderines y las fotos colgadas ============ */
  var swing = [];
  var TRI = [0xfcd116, 0x1c4fb8, 0xce1126];       // amarillo, azul y rojo
  (function(){
    var g = grp(3);
    var cobT = cv(128, 128, function(x){
      x.fillStyle = '#0b0a09'; x.fillRect(0, 0, 128, 128); x.strokeStyle = '#1a1714'; x.lineWidth = 2;
      for (var r = 0; r < 4; r++){ for (var c = -1; c < 4; c++){ x.strokeRect(c * 32 + (r % 2 ? 16 : 0) + 2, r * 32 + 2, 28, 28); } }
    }, [12, 16]);
    g.add(floor(42, 56, new THREE.MeshBasicMaterial({ map: cobT }), 0, Y0, -156));
    /* casas de pueblo: muro encalado, zócalo de color, puerta y ventana */
    function casaT(zoc, lit){
      return cv(512, 256, function(x){
        x.fillStyle = '#3b352c'; x.fillRect(0, 0, 512, 256);
        x.fillStyle = '#4a2318'; x.fillRect(0, 0, 512, 30); x.fillStyle = '#2d150e'; for (var i = 0; i < 26; i++){ x.beginPath(); x.arc(i * 20 + 10, 30, 10, 0, PI); x.fill(); }
        x.fillStyle = zoc; x.fillRect(0, 196, 512, 60);
        x.fillStyle = '#1c110a'; x.fillRect(70, 84, 86, 172); x.strokeStyle = zoc; x.lineWidth = 8; x.strokeRect(70, 84, 86, 176);
        x.fillStyle = lit ? '#ffb347' : '#14110d'; x.fillRect(260, 92, 150, 104);
        if (lit){ var gr = x.createRadialGradient(335, 144, 10, 335, 144, 170); gr.addColorStop(0, 'rgba(255,179,71,0.35)'); gr.addColorStop(1, 'rgba(255,179,71,0)'); x.fillStyle = gr; x.fillRect(120, 0, 392, 256); }
        x.strokeStyle = zoc; x.lineWidth = 8; x.strokeRect(260, 92, 150, 104);
        x.strokeStyle = '#1c110a'; x.lineWidth = 5; for (i = 1; i < 6; i++){ x.beginPath(); x.moveTo(260 + i * 25, 92); x.lineTo(260 + i * 25, 196); x.stroke(); }
      });
    }
    var casas = [casaT('#1f3f7a', true), casaT('#1f5c3a', false), casaT('#7a2222', true), casaT('#b8860b', true)];
    [-1, 1].forEach(function(sd){
      var row = new THREE.Group();
      for (var i = 0; i < 7; i++){
        var m = plane(8.2, 4.1, new THREE.MeshBasicMaterial({ map: casas[(i + (sd > 0 ? 2 : 0)) % 4] }));
        m.rotation.y = -sd * PI / 2; m.position.set(0, Y0 + 2.05, -132 - i * 8.2 + 0.1); row.add(m);
      }
      g.add(row); place(row, sd * 6.6, 0);
    });
    /* guirnaldas de bombillos cruzando la calle, con banderines */
    var bulbs = [], wires = [], triG = new THREE.BufferGeometry();
    triG.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-0.17, 0, 0, 0.17, 0, 0, 0, -0.4, 0]), 3));
    var flags = new THREE.InstancedMesh(triG, new THREE.MeshBasicMaterial({ side: THREE.DoubleSide }), 7 * 11);
    var dm = new THREE.Object3D(), fc = 0, cols = [0xffb347, 0xfcd116, 0x3f7dff, 0xff3b3b];
    for (var k = 0; k < 7; k++){
      var z = -135 - k * 6.4, px = null, py = null;
      for (var j = 0; j <= 12; j++){
        var x = -6.3 + j * 1.05, y = 4.5 - 1.0 * (1 - Math.pow(x / 6.3, 2));
        pushPt(bulbs, x, y - 0.08, z, cols[(j + k) % 4], 1);
        if (px !== null){
          wires.push(px, py, z, x, y, z);
          if (j > 0 && j < 12){ dm.position.set((px + x) / 2, (py + y) / 2 - 0.02, z + 0.01); dm.rotation.z = rr(-0.15, 0.15); dm.updateMatrix(); flags.setMatrixAt(fc, dm.matrix); flags.setColorAt(fc, new THREE.Color(TRI[(fc + k) % 3]).multiplyScalar(0.8)); fc++; }
        }
        px = x; py = y;
      }
    }
    flags.count = fc; g.add(flags); g.add(pts(bulbs, 0.62)); g.add(lineSeg(wires, 0x24201b));
    /* fotos 07–12 colgadas con ganchos de madera; se mecen con el viento */
    for (var i = 0; i < 6; i++){
      var sd = i % 2 ? 1 : -1, pv = new THREE.Group();
      var f = addPhoto(pv, pad2(i + 7), 2.05, { border: 0.08, maxW: 2.7 }), u = f.userData;
      f.position.y = -2.25 - u.h / 2 + 1.0;
      var top = f.position.y + u.h / 2 + 0.08;
      pv.add(lineSeg([-u.w * 0.36, top, 0, -u.w * 0.36, 0, 0, u.w * 0.36, top, 0, u.w * 0.36, 0, 0], 0x4a4136));
      [-1, 1].forEach(function(s2){ var peg = box(0.07, 0.2, 0.05, basic(0x9a7440)); peg.position.set(s2 * u.w * 0.36, top - 0.04, 0.02); pv.add(peg); });
      pv.position.set(0, 3.25, -140 - i * 6.4); pv.rotation.y = -sd * 0.36;
      pv.userData.ph = rnd() * TAU;
      g.add(pv); place(pv, sd * 2.4, 1, true); swing.push(pv);
    }
    lamp(g, -5.6, -150, 0xff9d3c, 4.0); lamp(g, 5.6, -166, 0xff9d3c, 4.0);
  })();

  /* ---- la chiva: cruza la calle y hace de telón entre la plaza y el despegue ---- */
  var chiva = new THREE.Group(), CHIVA_Z = -184;
  (function(){
    var sideT = cv(1024, 256, function(x){
      x.fillStyle = '#f2b90f'; x.fillRect(0, 0, 1024, 256);
      x.fillStyle = '#12489e'; x.fillRect(0, 150, 1024, 44); x.fillStyle = '#c4161c'; x.fillRect(0, 194, 1024, 62);
      x.fillStyle = '#c4161c'; x.fillRect(0, 0, 1024, 18);
      for (var i = 0; i < 6; i++){            // las bancas abiertas, con pasajeros a contraluz
        var px = 150 + i * 138;
        x.fillStyle = '#120c08'; x.beginPath(); x.moveTo(px, 142); x.lineTo(px, 66); x.arc(px + 56, 66, 56, PI, 0); x.lineTo(px + 112, 142); x.closePath(); x.fill();
        x.fillStyle = '#2a1c12'; x.beginPath(); x.arc(px + 36, 104, 15, 0, TAU); x.arc(px + 78, 110, 14, 0, TAU); x.fill(); x.fillRect(px + 18, 118, 78, 24);
        x.strokeStyle = '#12489e'; x.lineWidth = 6; x.beginPath(); x.moveTo(px - 3, 142); x.lineTo(px - 3, 66); x.arc(px + 56, 66, 59, PI, 0); x.lineTo(px + 115, 142); x.stroke();
      }
      for (i = 0; i < 26; i++){ x.fillStyle = i % 2 ? '#f2b90f' : '#ffffff'; x.beginPath(); x.moveTo(i * 40 + 20, 156); x.lineTo(i * 40 + 34, 172); x.lineTo(i * 40 + 20, 188); x.lineTo(i * 40 + 6, 172); x.closePath(); x.fill(); }
      x.fillStyle = '#fff3d0'; x.font = '700 44px ' + F_CON; x.textBaseline = 'middle'; x.fillText('FUSAGASUG\u00c1  \u2022  SUMAPAZ', 300, 226);
      x.fillStyle = '#120c08'; x.fillRect(20, 40, 96, 92);
    });
    var body = box(7.4, 1.75, 2.3, [basic(0xd9a40c), basic(0xb3202a), basic(0xb3202a), basic(0x0a0a0a), new THREE.MeshBasicMaterial({ map: sideT }), basic(0xd9a40c)]);
    body.position.y = Y0 + 1.55; chiva.add(body);
    var rack = box(7.0, 0.1, 2.2, basic(0x8f1820)); rack.position.y = Y0 + 2.55; chiva.add(rack);
    [[-2.2, 0x8a7a55, 0.7], [-1.0, 0x1c4fb8, 0.5], [0.3, 0x3d6b2a, 0.62], [1.6, 0x8a7a55, 0.45], [2.6, 0xc4161c, 0.4]].forEach(function(e){
      var b = box(1.0, e[2], 1.5, basic(e[1])); b.position.set(e[0], Y0 + 2.6 + e[2] / 2, 0); b.rotation.y = rr(-0.2, 0.2); chiva.add(b);
    });
    var wg = new THREE.CylinderGeometry(0.58, 0.58, 0.34, 18), hub = new THREE.CircleGeometry(0.26, 14);
    [-2.5, 1.6, 2.75].forEach(function(px){
      var w = new THREE.Mesh(wg, basic(0x060606)); w.rotation.x = PI / 2; w.position.set(px, Y0 + 0.58, 1.05); chiva.add(w);
      var h = new THREE.Mesh(hub, basic(0xf2b90f)); h.position.set(px, Y0 + 0.58, 1.23); chiva.add(h);
    });
    var bl = []; for (var i = 0; i < 15; i++){ pushPt(bl, -3.5 + i * 0.5, Y0 + 2.5, 1.2, [0xffb347, 0xfcd116, 0x3f7dff, 0xff3b3b][i % 4], 1); }
    chiva.add(pts(bl, 0.5));
    [0.5, -0.5].forEach(function(pz){ var h = glow(0xfff0c8, 3.4, 1); h.position.set(3.75, Y0 + 1.2, pz + 0.5); chiva.add(h); });
    chiva.position.z = CHIVA_Z; chiva.visible = false; journey.add(chiva);
  })();

  /* ============ 5. EL SALTO: la carretera se vuelve pista y se sube sobre las nubes ============ */
  var cloudsS = [];
  (function(){
    var g = grp(4);
    g.add(floor(80, 52, basic(0x050608), 0, Y0 - 0.02, -206));
    var rwT = cv(128, 256, function(x){
      x.fillStyle = '#0b0c0f'; x.fillRect(0, 0, 128, 256);
      x.fillStyle = 'rgba(230,232,236,0.38)'; x.fillRect(62, 30, 4, 120); x.fillRect(8, 0, 2, 256); x.fillRect(118, 0, 2, 256);
    }, [1, 5]);
    var rw = floor(9.4, 48, new THREE.MeshBasicMaterial({ map: rwT }), 0, Y0, -205); g.add(rw);
    respread.push(function(){ rw.scale.x = lerp(0.55, 1, kR); });
    [-1, 1].forEach(function(sd){
      var a = []; for (var z = -183; z > -228; z -= 2.4){ pushPt(a, 0, Y0 + 0.12, z, 0xdfeaff, 1); }
      var p = pts(a, 0.6); g.add(p); place(p, sd * 4.9, 0);
    });
    var c = []; for (var z = -183; z > -226; z -= 1.3){ pushPt(c, 0, Y0 + 0.08, z, 0xffb347, 0.9); }
    for (var x = -4; x <= 4; x += 0.8){ pushPt(c, x * 0.5, Y0 + 0.1, -182, 0x30ff7a, 1); pushPt(c, x * 0.5, Y0 + 0.1, -228, 0xff2a2a, 1); }
    g.add(pts(c, 0.5));
    /* el techo de nubes */
    for (var i = 0; i < (tier ? 34 : 16); i++){
      var s = new THREE.Sprite(new THREE.SpriteMaterial({ map: softT, color: 0x3a4766, transparent: true, opacity: rr(0.35, 0.6), depthWrite: false, fog: false }));
      s.position.set(rr(-26, 26), rr(6.5, 10.5), rr(-232, -200)); s.scale.set(rr(14, 24), rr(5, 9), 1);
      s.userData.drift = rr(-0.5, 0.5); g.add(s); cloudsS.push(s);
    }
  })();
