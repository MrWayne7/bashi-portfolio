(function(){
'use strict';

/* ============================================================
   CONFIG — contacto de BASHI
   ============================================================ */
var CONFIG = {
  whatsapp: '573245026518',
  instagram: 'https://www.instagram.com/sebxsco/',
  sitio: 'https://studiobashi.com/'
};

var TEX = __TEXMAP__;     // texturas de las 36 fotos: { "01": { u: ruta, a: proporción } }
var META = __META__;      // título y nota de cada foto
var LIBS = __LIBS__;

/* ============================================================
   EL VIAJE — una sola tabla manda sobre el mundo 3D, el ritmo y la interfaz
   [z donde empieza, título, frase, lugar que marca el visor, peso de scroll]
   peso > 1 = la escena se recorre más despacio (donde hay fotos)
   ============================================================ */
var Z0 = 8, TRAVEL = 528;
var SC = [
  [   8, 'El lente',    'Todo empieza con una cámara prestada.',          'DENTRO DE LA CAMARA',  1.0],
  [ -32, 'El rollo',    'Las primeras fotos, todavía con grano.',         'ROLLO 01',             1.5],
  [ -92, 'La niebla',   'Fusagasugá, Cundinamarca. De aquí soy.',         'FUSAGASUGA, CO',       0.8],
  [-130, 'La plaza',    'Bombillos, cuerdas y gente. La raíz.',           'FUSAGASUGA, CO',       1.4],
  [-180, 'El salto',    'De pueblo a ciudad, sin soltar la raíz.',        'BOG > USA',            0.8],
  [-230, 'Nueva York',  'Aprender a moverse en la ciudad.',               'NEW YORK, NY',         1.5],
  [-300, 'Miami',       'Neón, asfalto mojado y la Calle 8.',             'MIAMI, FL',            1.35],
  [-360, 'Atlanta',     'Donde la imagen se encuentra con el sonido.',    'ATLANTA, GA',          1.3],
  [-410, 'La mezcla',   'Vuelvo distinto. La raíz viene conmigo.',        'BOGOTA, CO',           1.1],
  [-450, 'El corte',    'Dirijo, edito, fotografío y mezclo.',            'BOGOTA, CO',           1.1],
  [-500, 'El visor',    'Jamás dejar de aprender.',                       'FOTOGRAMA 36',         0.9]
];
var ZEND = Z0 - TRAVEL;
function uOfZ(z){ return (Z0 - z) / TRAVEL; }
var CHU = SC.map(function(s){ return uOfZ(s[0]); });       // dónde empieza cada escena, en distancia (0..1)
/* en qué escena aparece cada foto (hasta qué número llega cada una) */
var FOTO_ESC = [[6, 'El rollo'], [12, 'La plaza'], [18, 'Nueva York'], [23, 'Miami'], [28, 'Atlanta'], [31, 'La mezcla'], [35, 'El corte'], [36, 'El visor']];
function escenaDe(key){ var n = parseInt(key, 10); for (var i = 0; i < FOTO_ESC.length; i++){ if (n <= FOTO_ESC[i][0]) return FOTO_ESC[i][1]; } return ''; }

/* ---------- las librerías se cargan sin frenar la página ---------- */
function loadScript(src){
  return new Promise(function(ok, fail){
    var s = document.createElement('script'); s.src = src; s.async = true;
    s.onload = ok; s.onerror = fail; document.head.appendChild(s);
  });
}
var threeReady = loadScript(LIBS.three);
var gsapReady = loadScript(LIBS.gsap).catch(function(){});

var $ = function(s, r){ return (r || document).querySelector(s); };
var $$ = function(s, r){ return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
var clamp = function(x, a, b){ a = a === undefined ? 0 : a; b = b === undefined ? 1 : b; return Math.min(b, Math.max(a, x)); };
var sstep = function(a, b, x){ var t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
var lerp = function(a, b, t){ return a + (b - a) * t; };
var pad2 = function(n){ return ('0' + n).slice(-2); };

var reduce = matchMedia('(prefers-reduced-motion: reduce)').matches;
var finePointer = matchMedia('(hover:hover) and (pointer:fine)').matches;
var SNAP = /[?&]snap/.test(location.search);   // solo para pruebas

var S = { p: 0, u: 0, mx: 0, my: 0, pt: -9999, shot: 0, sc: 0 };
var lenis = null;

/* ---------- calidad: se ajusta sola al equipo ---------- */
var Q = (function(){
  var m = /[?&]q=(high|mid|low)/.exec(location.search);
  var coarse = matchMedia('(pointer:coarse)').matches;
  var mem = navigator.deviceMemory || 8, cores = navigator.hardwareConcurrency || 8;
  var tier = coarse ? 1 : 2;                       // 2 alta, 1 media, 0 baja
  if (mem <= 4 || cores <= 4) tier = Math.max(0, tier - 1);
  if (m) tier = { high: 2, mid: 1, low: 0 }[m[1]];
  return { tier: tier, forced: !!m, coarse: coarse };
})();

var tickers = [];
var hero = $('#top');
var heroMax = 1;

/* ---------- contacto ---------- */
(function(){
  var wa = 'https://wa.me/' + CONFIG.whatsapp + '?text=' + encodeURIComponent('Hola BASHI, quiero reservar una sesión de fotos');
  $$('[data-wa]').forEach(function(a){ a.href = wa; });
  $$('[data-ig]').forEach(function(a){ a.href = CONFIG.instagram; });
  $$('[data-site]').forEach(function(a){ a.href = CONFIG.sitio; });
})();

/* ---------- puntero ---------- */
function setPointer(x, y){
  S.mx = x / window.innerWidth - 0.5; S.my = y / window.innerHeight - 0.5;
  S.cx = x; S.cy = y; S.moved = true; S.pt = performance.now();
}
window.addEventListener('pointermove', function(e){ setPointer(e.clientX, e.clientY); }, { passive: true });
['touchstart', 'touchmove'].forEach(function(ev){
  window.addEventListener(ev, function(e){ var t = e.touches && e.touches[0]; if (t) setPointer(t.clientX, t.clientY); }, { passive: true });
});

/* ---------- giroscopio: inclinar el teléfono mueve la mirada ---------- */
(function(){
  if (!Q.coarse || reduce || !window.DeviceOrientationEvent) return;
  var base = null, btn = $('#gyro');
  function onOri(e){
    if (e.gamma == null || e.beta == null) return;
    var land = Math.abs(window.orientation || 0) === 90;
    var gx = land ? e.beta : e.gamma, gy = land ? e.gamma : e.beta;
    if (!base) base = { x: gx, y: gy };
    S.gx = clamp((gx - base.x) / 28, -1, 1) * 0.5; S.gy = clamp((gy - base.y) / 28, -1, 1) * 0.5; S.gyro = true;
  }
  function start(){ window.addEventListener('deviceorientation', onOri, { passive: true }); }
  window.addEventListener('orientationchange', function(){ base = null; });
  if (typeof DeviceOrientationEvent.requestPermission === 'function'){      // iOS pide permiso con un toque
    if (!btn) return;
    btn.hidden = false;
    btn.addEventListener('click', function(){
      DeviceOrientationEvent.requestPermission().then(function(r){ if (r === 'granted') start(); btn.hidden = true; }).catch(function(){ btn.hidden = true; });
    });
  } else { start(); }
})();

/* ---------- progreso del viaje ---------- */
function measure(){ heroMax = Math.max(1, hero.offsetHeight - window.innerHeight); }
/* el scroll no avanza parejo: cada escena pesa distinto (tabla SC). RM = [scroll, distancia] */
var RM = (function(){
  var tot = 0, acc = 0, out = [[0, 0]], i, len;
  for (i = 0; i < SC.length; i++){ len = (i < SC.length - 1 ? SC[i + 1][0] : ZEND) - SC[i][0]; tot += -len * SC[i][4]; }
  for (i = 0; i < SC.length; i++){
    len = (i < SC.length - 1 ? SC[i + 1][0] : ZEND) - SC[i][0]; acc += -len * SC[i][4];
    out.push([acc / tot, i < SC.length - 1 ? CHU[i + 1] : 1]);
  }
  out[out.length - 1] = [1, 1];
  return out;
})();
function remap(p){
  for (var i = 0; i < RM.length - 1; i++){ if (p <= RM[i + 1][0]){ return RM[i][1] + (RM[i + 1][1] - RM[i][1]) * (p - RM[i][0]) / (RM[i + 1][0] - RM[i][0]); } }
  return 1;
}
function unmap(u){
  for (var i = 0; i < RM.length - 1; i++){ if (u <= RM[i + 1][1]){ return RM[i][0] + (RM[i + 1][0] - RM[i][0]) * (u - RM[i][1]) / (RM[i + 1][1] - RM[i][1]); } }
  return 1;
}
function onScroll(){ S.p = clamp(window.scrollY / heroMax); S.u = remap(S.p); }
measure(); onScroll();
window.addEventListener('scroll', onScroll, { passive: true });
window.addEventListener('resize', function(){ measure(); onScroll(); });
function goTo(y, dur){
  if (lenis) lenis.scrollTo(y, { duration: dur || 1.4 });
  else window.scrollTo({ top: y, behavior: (reduce || SNAP) ? 'auto' : 'smooth' });
}

/* ---------- cargador: solo espera las fuentes; el 3D entra después con un fundido ---------- */
var loaderEl = $('#loader'), loadN = $('#load-n');
var loadShown = 0, loadTarget = 0.35, loaderDone = false;
function finishLoader(){
  if (loaderDone) return; loaderDone = true; loadTarget = 1;
  setTimeout(function(){
    if (loaderEl) loaderEl.classList.add('done');
    document.documentElement.classList.add('ready');
    intro();
  }, 300);
}
tickers.push(function(){
  if (!loadN || loadShown > 0.999) return;
  loadShown += (loadTarget - loadShown) * 0.16;
  if (loadTarget === 1 && loadShown > 0.985) loadShown = 1;
  loadN.textContent = pad2(Math.round(loadShown * 36));     // el cargador cuenta los 36 fotogramas del rollo
});
setTimeout(finishLoader, 3200);   // nunca se queda pegado

var fontsReady = (document.fonts && document.fonts.load)
  ? Promise.race([
      Promise.all([document.fonts.load('400 80px "Pirata One"'), document.fonts.load('600 40px "Barlow Condensed"'),
                   document.fonts.load('700 40px "Barlow Condensed"'), document.fonts.load('400 24px "VT323"')]),
      new Promise(function(r){ setTimeout(r, 2600); })
    ]).catch(function(){})
  : Promise.resolve();

/* ---------- scroll con inercia (solo ratón/trackpad; en táctil manda el nativo) ---------- */
if (!reduce && !Q.coarse && !SNAP) loadScript(LIBS.lenis).then(function(){
  if (!window.Lenis) return;
  lenis = new window.Lenis({ lerp: 0.085, wheelMultiplier: 0.9, smoothWheel: true });
  tickers.push(function(now){ lenis.raf(now); });
  document.addEventListener('click', function(e){
    var a = e.target.closest && e.target.closest('a[href^="#"]'); if (!a) return;
    var el = document.querySelector(a.getAttribute('href')); if (!el) return;
    e.preventDefault(); lenis.scrollTo(el, { duration: 1.5 });
  });
}).catch(function(){});
