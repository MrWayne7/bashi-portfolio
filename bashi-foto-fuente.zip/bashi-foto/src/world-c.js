
  /* ============ CÁMARA ============ */
  /* puntos de control [z, x, y]. Cada tramo tiene su gesto:
     recta por el eje (lente y rollo), baja y lenta (niebla), a la altura de los ojos (plaza),
     despegue y picada (salto → Nueva York), deriva lateral (Miami), rodeo (la orquídea), a ras de piso (el corte) */
  var KEYS = [[20, 0, 0], [8, 0, 0], [-10, 0, 0], [-25, 0, 0], [-40, 0, 0], [-64, 0, 0], [-86, 0, 0],
    [-96, 0, -0.4], [-106, 0.5, -0.5], [-118, -0.5, -0.45], [-128, 0.2, -0.3],
    [-136, 0, 0.25], [-150, 0.45, 0.35], [-164, -0.45, 0.35], [-176, 0, 0.2],
    [-186, 0, -0.3], [-198, 0, -0.1], [-206, 0, 3.2], [-214, 0, 10.5], [-222, 0, 16.5], [-229, 0, 16],
    [-236, 0, 10.5], [-244, 0, 3.4], [-252, 0.3, 0.7], [-264, -0.5, 0.3], [-278, 0.5, 0.3], [-292, -0.3, 0.35],
    [-302, 0.4, 0.3], [-314, -1.3, 0.2], [-328, 1.3, 0.3], [-342, -1.0, 0.25], [-354, 0.2, 0.35],
    [-364, 0, 0.5], [-376, -0.6, 0.5], [-390, -0.9, 0.55], [-402, 0.2, 0.5], [-410, 0, 0.45],
    [-416, -0.6, 0.4], [-424, -2.5, 0.5], [-432, -3.3, 0.6], [-440, -1.7, 0.5], [-448, 0, 0.1],
    [-454, 0, -0.45], [-470, 0, -0.55], [-494, 0, -0.55],
    [-501, 0, -0.2], [-510, 0, 0], [-520, 0, 0], [-532, 0, 0], [-544, 0, 0]];
  function spl(z, c){
    var n = KEYS.length, i = 1;
    while (i < n - 3 && KEYS[i + 1][0] > z) i++;
    var a = KEYS[i - 1][c], b = KEYS[i][c], d = KEYS[i + 1][c], e = KEYS[i + 2][c];
    var f = clamp((KEYS[i][0] - z) / (KEYS[i][0] - KEYS[i + 1][0]));
    return 0.5 * ((2 * b) + (-a + d) * f + (2 * a - 5 * b + 4 * d - e) * f * f + (-a + 3 * b - 3 * d + e) * f * f * f);
  }
  /* en el corte la cámara no curva: salta de carril en cada corte */
  function laneX(z){
    var x = -sstep(-449, -453, z), i;
    for (i = 0; i < CUTS.length; i++){
      var next = i < CUTS.length - 1 ? LANES[i + 1] : 0;
      x = lerp(x, next, sstep(CUTS[i] + 0.35, CUTS[i] - 0.35, z));
    }
    return x * LANE_W * lerp(0.5, 1, kR);
  }
  function pathZ(p){ return Z0 - p * TRAVEL; }
  function xAt(z){
    if (z < -449 && z > -503) return laneX(z);
    var a = (z < -412 && z > -449) ? lerp(0.6, 1, kR) : AMP / 2.4;      // el rodeo a la orquídea no se encoge tanto en teléfono
    return spl(z, 1) * a;
  }
  function pathX(p){ return xAt(pathZ(p)); }
  function pathY(p){ return spl(pathZ(p), 2); }
  /* giro sobre el eje: la cámara rota al entrar por el lente y sigue girando dentro del rollo */
  function rollAt(z){
    if (z > -25) return 2.2 * clamp((Z0 - z) / 33);
    if (z > -90){ var f = clamp((-25 - z) / 65); return 2.2 + (TAU - 2.2) * (1 - Math.pow(1 - f, 1.7)); }
    if (z < -303 && z > -358) return 0.055 * Math.sin((z + 303) * 0.115) * sstep(-303, -309, z) * sstep(-358, -352, z);
    return 0;
  }
  var CUT_K = 0;
  function cutAt(z){ var k = 0; for (var i = 0; i < CUTS.length; i++){ k = Math.max(k, 1 - Math.abs(z - CUTS[i]) / 0.4); } return clamp(k); }

  /* ============ POSTPROCESADO: resplandor, grano y aberración ============ */
  var post = (function(){
    var tri = new THREE.BufferGeometry();
    tri.setAttribute('position', new THREE.BufferAttribute(new Float32Array([-1, -1, 0, 3, -1, 0, -1, 3, 0]), 3));
    tri.setAttribute('uv', new THREE.BufferAttribute(new Float32Array([0, 0, 2, 0, 0, 2]), 2));
    var VS = 'varying vec2 vUv; void main(){ vUv=uv; gl_Position=vec4(position.xy,0.0,1.0); }';
    var blur = new THREE.ShaderMaterial({ uniforms: { t: { value: null }, d: { value: new THREE.Vector2() } }, vertexShader: VS, depthTest: false, depthWrite: false,
      fragmentShader: 'uniform sampler2D t; uniform vec2 d; varying vec2 vUv; void main(){ vec3 c=texture2D(t,vUv).rgb*0.227; c+=(texture2D(t,vUv+d*1.385).rgb+texture2D(t,vUv-d*1.385).rgb)*0.316; c+=(texture2D(t,vUv+d*3.231).rgb+texture2D(t,vUv-d*3.231).rgb)*0.0703; gl_FragColor=vec4(c,1.0); }' });
    var comp = new THREE.ShaderMaterial({
      uniforms: { tS: { value: null }, tB: { value: null }, uBloom: { value: 0.5 }, uCA: { value: 0.001 }, uGrain: { value: 0.05 },
                  uTime: U.time, uVig: { value: 0.55 }, uRes: { value: new THREE.Vector2(1, 1) } },
      vertexShader: VS, depthTest: false, depthWrite: false,
      fragmentShader: [
        'uniform sampler2D tS,tB; uniform float uBloom,uCA,uGrain,uTime,uVig; uniform vec2 uRes; varying vec2 vUv;',
        'float hs(vec2 p){ return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453); }',
        'void main(){',
        '  vec2 c=vUv-0.5; float r2=dot(c,c); vec2 o=c*uCA*(0.35+r2*2.6);',
        '  vec3 col=vec3(texture2D(tS,vUv+o).r, texture2D(tS,vUv).g, texture2D(tS,vUv-o).b);',
        '  vec3 bl=texture2D(tB,vUv).rgb;',
        '  float lum=dot(bl,vec3(0.3,0.59,0.11)); col+=bl*smoothstep(0.34,1.0,lum)*uBloom;',
        '  col*=1.0-uVig*r2*1.7;',
        '  col+=(hs(floor(vUv*uRes*0.5)+fract(uTime)*61.0)-0.5)*uGrain;',
        '  gl_FragColor=vec4(col,1.0);',
        '}'].join('\n') });
    var qs = new THREE.Scene(), qc = new THREE.Camera(), qm = new THREE.Mesh(tri, blur); qm.frustumCulled = false; qs.add(qm);
    var rtS = null, rtA = null, rtB = null, W = 1, H = 1;
    function pass(mat, target){ qm.material = mat; renderer.setRenderTarget(target); renderer.render(qs, qc); }
    return {
      comp: comp,
      forget: function(){ rtS = rtA = rtB = null; },
      size: function(w, h, pr){
        W = Math.max(2, Math.floor(w * pr)); H = Math.max(2, Math.floor(h * pr));
        [rtS, rtA, rtB].forEach(function(r){ if (r) r.dispose(); });
        if (gl2 && THREE.WebGLMultisampleRenderTarget && tier === 2){ rtS = new THREE.WebGLMultisampleRenderTarget(W, H); rtS.samples = 4; }
        else rtS = new THREE.WebGLRenderTarget(W, H);
        rtS.texture.minFilter = rtS.texture.magFilter = THREE.LinearFilter;
        var w4 = Math.max(2, W >> 2), h4 = Math.max(2, H >> 2);
        rtA = new THREE.WebGLRenderTarget(w4, h4, { depthBuffer: false }); rtB = new THREE.WebGLRenderTarget(w4, h4, { depthBuffer: false });
        comp.uniforms.uRes.value.set(W, H);
      },
      render: function(sc, cam){
        renderer.setRenderTarget(rtS); renderer.render(sc, cam);
        var w4 = rtA.width, h4 = rtA.height;
        blur.uniforms.t.value = rtS.texture; blur.uniforms.d.value.set(1 / w4, 0); pass(blur, rtA);
        blur.uniforms.t.value = rtA.texture; blur.uniforms.d.value.set(0, 1 / h4); pass(blur, rtB);
        blur.uniforms.t.value = rtB.texture; blur.uniforms.d.value.set(2 / w4, 0); pass(blur, rtA);
        blur.uniforms.t.value = rtA.texture; blur.uniforms.d.value.set(0, 2 / h4); pass(blur, rtB);
        comp.uniforms.tS.value = rtS.texture; comp.uniforms.tB.value = rtB.texture;
        pass(comp, null);
      }
    };
  })();

  /* ---- calidad adaptativa ---- */
  var PR_TIER = [1, 1.5, 2];
  var acc = 0, accN = 0, warm = 0, skipFrame = false;
  document.addEventListener('visibilitychange', function(){ skipFrame = true; });
  function watchFps(dt){        // mide por tiempo real: un equipo muy lento también baja de nivel
    if (Q.forced || tier === 0) return;
    if (skipFrame){ skipFrame = false; return; }
    warm += dt; if (warm < 1.5) return;
    acc += dt; accN++;
    if (acc >= 2.5){
      if (acc / accN > 0.03){ tier--; warm = 0; resize(); }
      acc = 0; accN = 0;
    }
  }

  var tmp = new THREE.Vector3(), tgt = new THREE.Vector3();
  function resize(){
    var w = window.innerWidth, h = window.innerHeight;
    var pr = Math.min(window.devicePixelRatio || 1, PR_TIER[tier], w < 900 ? 1.5 : 2);
    renderer.setPixelRatio(pr);
    renderer.setSize(w, h, false);
    if (tier > 0) post.size(w, h, pr);
    aspect = w / h; camera.aspect = aspect;
    kR = clamp((aspect - 0.46) / (1.6 - 0.46));
    spread = lerp(0.47, 1, kR); sizeK = lerp(0.62, 1, kR); AMP = lerp(0.55, 2.4, kR); baseFov = lerp(68, 52, kR);
    camera.fov = baseFov; camera.updateProjectionMatrix();
    applySpread();
    /* la última foto queda a la distancia exacta en que cubre toda la pantalla */
    var u = lastPhoto.userData, tf = Math.tan(baseFov * PI / 360);
    var dCover = Math.min((u.h / 2) / tf, (u.w / 2) / (tf * aspect));
    lastPhoto.position.set(0, 0, ZEND - dCover * 0.985);
    journey.updateMatrixWorld(true);
    photos.forEach(function(g){ g.userData.mesh.getWorldPosition(g.userData.wp); });
  }
  resize(); window.addEventListener('resize', resize);

  /* ---- tocar una foto: la cámara vuela hasta ella ---- */
  var focus = { g: null, k: 0, pos: new THREE.Vector3(), look: new THREE.Vector3(), _p: null, _l: null };
  var ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), journeyOn = false, nrm = new THREE.Vector3(), qW = new THREE.Quaternion();
  function pick(cx, cy){
    if (!journeyOn) return null;
    ndc.set(cx / window.innerWidth * 2 - 1, -(cy / window.innerHeight) * 2 + 1);
    ray.setFromCamera(ndc, camera); ray.far = 26;
    var hit = ray.intersectObjects(pickables, false)[0];
    return hit && hit.object.userData.frame !== lastPhoto ? hit.object.userData.frame : null;
  }
  function setFocus(g){
    focus.g = g; if (!g) return;
    var u = g.userData, m = u.mesh;
    m.getWorldPosition(focus.look); m.getWorldQuaternion(qW); m.getWorldScale(tmp);
    var s = tmp.y, tf = Math.tan(baseFov * PI / 360), wide = aspect > 1.15;
    var hh = (u.h * s) / 2 + 0.4, hw = (u.w * s) / 2 + 0.3;
    var dist = Math.max(hh / (tf * (wide ? 1 : 0.62)), hw / (tf * aspect * (wide ? 0.55 : 1)));
    nrm.set(0, 0, 1).applyQuaternion(qW);
    if (nrm.z < 0) nrm.negate();
    focus.pos.copy(focus.look).addScaledVector(nrm, dist);
    /* la foto queda a la derecha (escritorio) o arriba (teléfono) para dejarle sitio a la ficha */
    if (wide){ tmp.set(nrm.z, 0, -nrm.x).normalize().multiplyScalar(tf * dist * aspect * 0.36); focus.look.sub(tmp); focus.pos.sub(tmp); }
    else { focus.look.y -= tf * dist * 0.3; focus.pos.y -= tf * dist * 0.3; }
  }
  SKY = {
    pick: function(x, y){ var g = pick(x, y); return g ? g.userData.info : null; },
    focus: function(x, y){ var g = pick(x, y); if (!g) return null; setFocus(g); return g.userData.info; },
    unfocus: function(){ focus.g = null; },
    tier: function(){ return tier; }
  };

  var burnEl = $('#burn'), cutEl = $('#cutk'), lastBurn = -1, lastCut = -1;
  var FST = ['16', '11', '8', '5.6', '4', '2.8', '2', '1.4'];
  var texTick = 0;
  var pS = S.p, pPrev = S.p, vel = 0, tx = 0, ty = 0, t = 0, last = performance.now(), kick = 0;
  var pA = new THREE.Vector3(), qA = new THREE.Quaternion(), qB = new THREE.Quaternion(), cA = new THREE.Color(), cloudCol = new THREE.Color(0x232c40);

  function frame(now){
    var rawDt = (now - last) / 1000, dt = Math.min(0.05, rawDt); last = now;
    var hr = hero.getBoundingClientRect();
    var showJ = hr.bottom > 0;
    journeyOn = showJ;
    if (lost || !showJ) return;
    if (!shown){ shown = true; document.documentElement.classList.add('gl-on'); }
    if (!reduce) t += dt;
    U.time.value = t;

    var gmx = S.gyro ? S.gx : S.mx, gmy = S.gyro ? S.gy : S.my;
    tx += (gmx - tx) * 0.05; ty += (gmy - ty) * 0.05;
    var ptx = reduce ? 0 : tx, pty = reduce ? 0 : ty;

    pS += (S.p - pS) * ((reduce || SNAP) ? 1 : 0.075);
    vel += (((pS - pPrev) / Math.max(dt, 0.001)) - vel) * 0.1; pPrev = pS; if (SNAP) vel = 0;
    var p = remap(pS);
    var cz = pathZ(p), cx = pathX(p), cy = pathY(p);

    /* ambiente: se mezcla entre la escena actual y la que sigue */
    var si = 0, i; for (i = 0; i < CHU.length; i++){ if (p >= CHU[i]) si = i; }
    var nx = Math.min(si + 1, ENV.length - 1), bk = si < ENV.length - 1 ? sstep(CHU[nx] - 0.012, CHU[nx], p) : 0;
    var E = ENV[si], E2 = ENV[nx];
    bg.copy(E[0]).lerp(E2[0], bk);
    var fogN = lerp(E[1], E2[1], bk), fogF = lerp(E[2], E2[2], bk), bloom = lerp(E[3], E2[3], bk), grain = lerp(E[4], E2[4], bk);
    var cloudK = (si === 4 || si === 5) ? sstep(5, 7.5, cy) * sstep(13, 10, cy) : 0;      // al cruzar el techo de nubes
    if (cloudK > 0){ bg.lerp(cloudCol, cloudK * 0.85); fogN = lerp(fogN, 0.5, cloudK); fogF = lerp(fogF, 13, cloudK); }
    var endK = sstep(-93, -86, cz) * sstep(-99, -93, cz);                                 // la luz al fondo del rollo
    if (endK > 0){ bg.lerp(cA.set(0x2a1808), endK * 0.6); }
    scene.fog.color.copy(bg); scene.fog.near = fogN; scene.fog.far = fogF;
    U.fogNear.value = fogN; U.fogFar.value = fogF;

    /* solo se dibuja lo que está cerca */
    for (i = 0; i < G.length; i++){
      var z1 = i < SC.length - 1 ? SC[i + 1][0] : ZEND - 12;
      G[i].visible = cz < SC[i][0] + 64 && cz > z1 - 16;
    }

    /* telón de fondo */
    var B = BK[si], B2 = BK[nx];
    back.position.set(cx, cy, cz);
    mtnM.opacity = lerp(B[0], B2[0], bk) * (1 - cloudK); mtnM.visible = mtnM.opacity > 0.01;
    var stK = lerp(B[1], B2[1], bk) * (cloudK > 0 ? sstep(9, 13, cy) : 1) * (si === 4 ? sstep(8, 13, cy) * 0.75 + 0.25 : 1);
    starsM.opacity = stK; starsM.visible = stK > 0.01; moon.material.opacity = stK * 0.9; moon.visible = stK > 0.01;
    skyM.opacity = lerp(B[2], B2[2], bk); skyM.visible = skyM.opacity > 0.01;
    monse.material.opacity = (si === 8 ? 1 : 0) * (1 - bk); monse.visible = monse.material.opacity > 0.01;
    hzM.color.copy(B[3]).lerp(B2[3], bk); hzM.opacity = lerp(B[4], B2[4], bk) * (1 - cloudK); hzM.visible = hzM.opacity > 0.01;

    /* cámara */
    camera.position.set(cx + ptx * 0.5, cy - pty * 0.3, cz);
    var pa = p + 6 / TRAVEL;
    tgt.set(pathX(pa) * 0.92 + ptx * 1.2, pathY(pa) - pty * 0.7, cz - 6);
    /* la mirada se va hacia cada foto al pasar */
    var lookX = 0, lookY = 0, d, w, g, u;
    if (cz < -34 && cz > ZEND + 22){
      for (i = 0; i < photos.length; i++){
        u = photos[i].userData; d = cz - u.wp.z;
        if (d > 1.5 && d < 16){ w = sstep(16, 8, d) * sstep(1.5, 5, d); lookX += (u.wp.x - cx) * 0.3 * w; lookY += (u.wp.y - cy) * 0.2 * w; }
      }
      d = cz - ORCH_Z; if (d > -2 && d < 22){ w = sstep(22, 10, d) * sstep(-2, 3, d); lookX += (orchid.position.x - cx) * 0.75 * w; lookY += (1.5 - cy) * 0.5 * w; }
    }
    var lk = sstep(5, 1.6, cy);       // en la picada la mirada no se distrae
    tgt.x += clamp(lookX, -3.4, 3.4) * lk; tgt.y += clamp(lookY, -1.6, 1.6) * lk;
    camera.lookAt(tgt);

    /* el bajo de Atlanta sacude la cámara */
    var bph = (t * 1.1667) % 1, beat = Math.exp(-bph * 7) + Math.exp(-((bph + 0.5) % 1) * 10) * 0.45;
    var atlK = reduce ? 0 : sstep(-363, -367, cz) * sstep(-410, -404, cz);
    if (!reduce){
      var bank = clamp(-(pathX(p + 1 / TRAVEL) - pathX(p - 1 / TRAVEL)) * 0.3, -0.07, 0.07) * (cz < -449 ? 0 : 1);
      camera.rotateZ(rollAt(cz) + bank + Math.sin(t * 37) * beat * 0.007 * atlK);
      camera.position.y += beat * 0.05 * atlK;
    }

    /* foco en una foto */
    focus.k += ((focus.g ? 1 : 0) - focus.k) * (reduce ? 1 : 0.07);
    if (focus.k > 0.002){
      var e = focus.k * focus.k * (3 - 2 * focus.k);
      pA.copy(camera.position); qA.copy(camera.quaternion);
      if (focus.g){ focus._p = focus.pos; focus._l = focus.look; }
      tmp.copy(focus._p); if (!reduce){ tmp.x += Math.sin(t * 0.45) * 0.12; tmp.y += Math.sin(t * 0.33) * 0.08; }
      camera.position.copy(tmp); camera.lookAt(focus._l); qB.copy(camera.quaternion);
      camera.position.lerpVectors(pA, tmp, e); camera.quaternion.copy(qA).slerp(qB, e);
    }
    kick += ((reduce || focus.g ? 0 : Math.min(Math.abs(vel) * 90, 13)) - kick) * 0.08;
    camera.fov = baseFov + kick + beat * 1.1 * atlK; camera.updateProjectionMatrix();
    camera.updateMatrixWorld();

    /* 1 · el diafragma se abre */
    if (G[0].visible){
      var ik = sstep(7, -19, cz), ir = lerp(0.14, 4.6, ik);
      for (i = 0; i < 8; i++){ var b = iris[i], ba = b.userData.a; b.position.x = Math.cos(ba) * (ir + 4); b.position.y = Math.sin(ba) * (ir + 4); }
      S.fstop = FST[Math.min(7, Math.floor(ik * 7.999))];
    } else S.fstop = '1.4';
    var burn = clamp(1 - Math.abs(cz + 28.2) / 4.6);
    burn = burn * burn * (3 - 2 * burn);
    if (Math.abs(burn - lastBurn) > 0.004){ lastBurn = burn; if (burnEl) burnEl.style.opacity = burn.toFixed(3); }

    /* texturas por escena + revelado + cuántas fotos van */
    var shot = 0;
    if ((texTick++ % 8) === 0){
      for (i = 0; i < photos.length; i++){ g = photos[i]; d = cz - g.userData.wp.z; if (d < 72 && d > -16) ensureTex(g); else if (d > 100 || d < -30) dropTex(g); }
    }
    for (i = 0; i < photos.length; i++){
      u = photos[i].userData; d = cz - u.wp.z;
      if (d < 1.2) shot++;
      if (u.dev) u.mat.uniforms.uDev.value = focus.g === photos[i] ? 0 : sstep(7.5, 22, d);
    }
    S.shot = Math.min(36, shot + (p > 0.999 ? 1 : 0));

    /* 3 y 9 · niebla que deriva */
    if (G[2].visible || G[8].visible){ for (i = 0; i < mist.length; i++){ var ms = mist[i]; if (!reduce){ ms.position.x += ms.userData.drift * dt; if (ms.position.x > ms.userData.x1) ms.position.x = ms.userData.x0; else if (ms.position.x < ms.userData.x0) ms.position.x = ms.userData.x1; } } }
    /* 4 · las fotos colgadas se mecen */
    if (G[3].visible){ for (i = 0; i < swing.length; i++){ var sw = swing[i]; sw.rotation.z = Math.sin(t * 0.9 + sw.userData.ph) * 0.045; sw.rotation.x = Math.sin(t * 0.7 + sw.userData.ph * 2) * 0.03; } }
    /* la chiva cruza */
    var chk = (-171 - cz) / 9;
    chiva.visible = chk > 0 && chk < 1 && !reduce;
    if (chiva.visible){ var cw = 13 + 9 * kR; chiva.position.x = lerp(-cw, cw, chk); chiva.position.y = Math.abs(Math.sin(t * 9)) * 0.035; chiva.scale.setScalar(lerp(0.72, 1.15, kR)); }
    /* 5 · nubes */
    if (G[4].visible && !reduce){ for (i = 0; i < cloudsS.length; i++){ cloudsS[i].position.x += cloudsS[i].userData.drift * dt; } }
    /* 6 · el tren pasa y su luz corta la calle a golpes */
    if (G[5].visible){
      var trx = ((t * 13) % 110) - 66; train.position.x = trx;
      var near = clamp(1 - Math.abs(trx + 11) / 16), fl = reduce ? 0 : near * (Math.sin(t * 43) > 0.15 ? 1 : 0.25);
      spark.material.opacity = fl * 0.55; spark.position.x = clamp(trx + 11, -4, 4);
      for (i = 0; i < nyPhotos.length; i++){ nyPhotos[i].userData.mat.uniforms.uTint.value.setScalar(1 + fl * 0.45); }
      for (i = 0; i < steam.length; i++){
        var sm = steam[i], sp = (t * 0.2 + sm.userData.ph) % 1;
        sm.position.set(sm.userData.x * spread + Math.sin(sp * 5 + i) * 0.35, Y0 + 0.2 + sp * 4.4, sm.userData.z); sm.scale.setScalar(1.1 + sp * 3.6); sm.material.opacity = Math.sin(PI * sp) * 0.17;
      }
    }
    /* 7 · el carro de adelante */
    car.visible = cz < -304 && cz > -343;
    if (car.visible){ var carZ = cz - lerp(13, 9.5, kR) - Math.sin(t * 0.4) * 0.8, cs = lerp(0.7, 1, kR); car.scale.setScalar(cs); car.position.set(xAt(carZ) * 0.5, Y0 * (1 - cs), carZ); car.rotation.y = (xAt(carZ - 2) - xAt(carZ + 2)) * 0.08; }
    /* 8 · los parlantes laten */
    if (G[7].visible){ for (i = 0; i < woofers.length; i++){ woofers[i].scale.setScalar(1 + (reduce ? 0 : beat * 0.13)); } }
    /* 9 · la orquídea */
    if (G[8].visible){ orchid.rotation.y = reduce ? -0.4 : -0.4 + Math.sin(t * 0.45) * 0.55; orchid.userData.flower.position.y = 1.7 + (reduce ? 0 : Math.sin(t * 0.8) * 0.05); }
    /* 10 · el cabezal y los cortes */
    var inCut = cz < -451 && cz > -499;
    playhead.visible = inCut;
    if (inCut) playhead.position.z = cz - 7;
    var ck = (reduce || !inCut) ? 0 : cutAt(cz);
    if (Math.abs(ck - lastCut) > 0.004){ lastCut = ck; if (cutEl) cutEl.style.opacity = ck > 0.02 ? '1' : '0'; }
    if (inCut){ var fr = Math.floor((-451 - cz) * 12); S.tc = '00:00:' + pad2(Math.floor(fr / 24) % 60) + ':' + pad2(fr % 24); } else S.tc = '';

    if (tier === 0){ renderer.setRenderTarget(null); renderer.render(scene, camera); }
    else {
      var cu = post.comp.uniforms;
      cu.uBloom.value = bloom; cu.uVig.value = 0.55 * (1 - sstep(0.985, 1, p));
      cu.uCA.value = reduce ? 0 : 0.0012 + Math.min(Math.abs(vel) * 0.05, 0.008) + beat * 0.0018 * atlK;
      cu.uGrain.value = grain;
      post.render(scene, camera);
    }
    watchFps(rawDt);
  }
  tickers.push(frame);
}
Promise.all([threeReady, fontsReady]).then(function(){ try { initWorld(); } catch (e) { console.error(e); skyOff(); } }, skyOff);

